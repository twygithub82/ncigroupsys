-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer_company`
--

DROP TABLE IF EXISTS `customer_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_company` (
  `guid` varchar(36) NOT NULL,
  `currency_guid` varchar(36) DEFAULT NULL,
  `type_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = CUSTOMER_TYPE',
  `name` varchar(50) DEFAULT NULL,
  `code` varchar(10) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `alias` varchar(100) DEFAULT NULL,
  `address_line1` varchar(255) DEFAULT NULL,
  `address_line2` varchar(255) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `postal` varchar(20) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `fax` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `website` varchar(45) DEFAULT NULL,
  `effective_dt` bigint DEFAULT NULL,
  `agreement_due_dt` bigint DEFAULT NULL,
  `update_dt` bigint DEFAULT NULL,
  `update_by` varchar(45) DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_company`
--

LOCK TABLES `customer_company` WRITE;
/*!40000 ALTER TABLE `customer_company` DISABLE KEYS */;
INSERT INTO `customer_company` VALUES ('5d8f899e2e5011ef91a300ff079339a5','USD','OWNER','Tech Innovations Ltd.','TIL','A leading technology solutions provider','TechInnov_Alias','123 Tech Park','Suite 400','San Francisco','USA','94107','+1-800-555-0100','+1-800-555-0200','info@techinnov.com','https://www.techinnov.com',1704038400,1735660800,1718810817,'admin',1701360000,'admin',NULL),('5d8fa01e2e5011ef91a300ff079339a5','USD','OWNER','Global Trade Corp.','GTC','International trading company specializing in raw materials','GlobalTrade_Alias','456 Market St','Floor 5','New York','USA','10005','+1-800-555-0300','+1-800-555-0400','contact@globaltrade.com','https://www.globaltrade.com',1682870400,1714492800,1718810817,'admin',1680278400,'admin',NULL),('5d8fa4f02e5011ef91a300ff079339a5','USD','OWNER','Eco Solutions Inc.','ESI','Sustainable energy solutions provider','EcoSolutions_Alias','789 Green Way','Building 2','Austin','USA','73301','+1-800-555-0500','+1-800-555-0600','support@ecosolutions.com','https://www.ecosolutions.com',1693497600,1725120000,1718810817,'admin',1690819200,'admin',NULL),('5d8fa7822e5011ef91a300ff079339a5','USD','OWNER','MediCare Health Ltd.','MCH','Provider of healthcare and medical services','MediCare_Alias','123 Wellness Blvd','Room 101','Chicago','USA','60601','+1-800-555-0700','+1-800-555-0800','info@medicare.com','https://www.medicare.com',1709222400,1740758400,1718810817,'admin',1675180800,'admin',NULL),('5d8faa9d2e5011ef91a300ff079339a5','USD','OWNER','NextGen Automotive','NGA','Manufacturer of electric vehicles and components','NextGenAuto_Alias','456 Drive St','Suite 202','Detroit','USA','48201','+1-800-555-0900','+1-800-555-1000','sales@nextgenauto.com','https://www.nextgenauto.com',1688140800,1719763200,1718810817,'admin',1685548800,'admin',NULL),('6d8fb9de2e5011ef91a300ff079339a5','USD','OWNER','Tech Innovators Co.','TIC','Pioneers in tech innovations','TechInnovCo_Alias','789 Innovation Drive','Suite 500','Silicon Valley','USA','94027','+1-800-555-1100','+1-800-555-1200','contact@techinnovco.com','https://www.techinnovco.com',1704038401,1735660801,1718810818,'admin',1701360001,'admin',NULL),('6d8fbc0e2e5011ef91a300ff079339a5','USD','OWNER','Global Logistics Inc.','GLI','Leading provider of global logistics services','GlobalLog_Alias','321 Freight St','Floor 6','Miami','USA','33101','+1-800-555-1300','+1-800-555-1400','info@globallog.com','https://www.globallog.com',1682870401,1714492801,1718810818,'admin',1680278401,'admin',NULL),('6d8fbe322e5011ef91a300ff079339a5','USD','OWNER','Eco Energy Solutions','EES','Renewable energy solutions provider','EcoEnergy_Alias','123 Solar Park','Building 3','San Diego','USA','92101','+1-800-555-1500','+1-800-555-1600','support@ecoenergy.com','https://www.ecoenergy.com',1693497601,1725120001,1718810818,'admin',1690819201,'admin',NULL),('6d8fc0422e5011ef91a300ff079339a5','USD','OWNER','MediCare Global Ltd.','MGL','Global provider of healthcare services','MediCareGlobal_Alias','456 Wellness Avenue','Room 202','Los Angeles','USA','90001','+1-800-555-1700','+1-800-555-1800','info@medicareglobal.com','https://www.medicareglobal.com',1709222401,1740758401,1718810818,'admin',1675180801,'admin',NULL),('6d8fc2522e5011ef91a300ff079339a5','USD','OWNER','NextGen Technologies','NGT','Next-generation tech solutions provider','NextGenTech_Alias','789 Future Blvd','Suite 303','Seattle','USA','98101','+1-800-555-1900','+1-800-555-2000','sales@nextgentech.com','https://www.nextgentech.com',1688140801,1719763201,1718810818,'admin',1685548801,'admin',NULL),('6d8fc4622e5011ef91a300ff079339a5','USD','OWNER','BioHealth Innovations','BHI','Innovative healthcare solutions provider','BioHealth_Alias','123 Health St','Floor 4','Boston','USA','02108','+1-800-555-2100','+1-800-555-2200','info@biohealth.com','https://www.biohealth.com',1698768001,1730390401,1718810818,'admin',1696070401,'admin',NULL),('6d8fc6722e5011ef91a300ff079339a5','USD','OWNER','AgriWorld Ltd.','AWL','Provider of agricultural solutions','AgriWorld_Alias','456 Farm Road','Suite 404','Dallas','USA','75201','+1-800-555-2300','+1-800-555-2400','contact@agriworld.com','https://www.agriworld.com',1709395201,1741017601,1718810818,'admin',1706716801,'admin',NULL),('6d8fc8822e5011ef91a300ff079339a5','USD','OWNER','FutureTech Corp.','FTC','Cutting-edge technology solutions','FutureTech_Alias','789 Progress Ave','Room 505','Denver','USA','80202','+1-800-555-2500','+1-800-555-2600','info@futuretech.com','https://www.futuretech.com',1719849601,1751472001,1718810818,'admin',1717171201,'admin',NULL),('6d8fca922e5011ef91a300ff079339a5','USD','OWNER','GreenWorld Solutions','GWS','Provider of green technology solutions','GreenWorld_Alias','123 Greenway','Suite 606','Portland','USA','97201','+1-800-555-2700','+1-800-555-2800','support@greenworld.com','https://www.greenworld.com',1722480001,1754102401,1718810818,'admin',1719811201,'admin',NULL),('6d8fccb22e5011ef91a300ff079339a5','USD','OWNER','InnoBioTech Ltd.','IBT','Innovative biotech solutions','InnoBioTech_Alias','456 Bio Rd','Floor 7','San Jose','USA','95101','+1-800-555-2900','+1-800-555-3000','info@innobiotech.com','https://www.innobiotech.com',1730294401,1761916801,1718810818,'admin',1727616001,'admin',NULL);
/*!40000 ALTER TABLE `customer_company` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`idms_admin`@`%`*/ /*!50003 TRIGGER `customer_company_AFTER_INSERT` AFTER INSERT ON `customer_company` FOR EACH ROW BEGIN
    -- Call the stored procedure and pass parameters from the NEW row
     CALL SP_New_Customer_CleaningCategory(NEW.guid, NEW.create_by, NEW.create_dt);
     CALL SP_New_Customer_PackageBuffer(NEW.guid, NEW.create_by, NEW.create_dt);    
	 CALL SP_New_Customer_PackageDepot(NEW.guid, NEW.create_by, NEW.create_dt);  
     CALL SP_New_Customer_PackageLabour(NEW.guid, NEW.create_by, NEW.create_dt); 
	 CALL SP_New_Customer_PackageRepair(NEW.guid, NEW.create_by, NEW.create_dt); 
     CALL SP_New_Customer_PackageResidue(NEW.guid, NEW.create_by, NEW.create_dt);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-28 22:11:48
