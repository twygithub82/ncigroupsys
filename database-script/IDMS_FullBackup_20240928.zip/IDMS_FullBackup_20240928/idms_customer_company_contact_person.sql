-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer_company_contact_person`
--

DROP TABLE IF EXISTS `customer_company_contact_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_company_contact_person` (
  `guid` varchar(36) NOT NULL,
  `customer_guid` varchar(36) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `title_cv` varchar(20) NOT NULL,
  `job_title` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `department_id` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email_alert` tinyint DEFAULT '0',
  `delete_dt` bigint unsigned DEFAULT NULL,
  `update_dt` bigint unsigned DEFAULT NULL,
  `update_by` varchar(45) DEFAULT NULL,
  `create_dt` bigint unsigned DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_company_contact_person`
--

LOCK TABLES `customer_company_contact_person` WRITE;
/*!40000 ALTER TABLE `customer_company_contact_person` DISABLE KEYS */;
INSERT INTO `customer_company_contact_person` VALUES ('deaef0212e5011ef91a300ff079339a5','5d8f899e2e5011ef91a300ff079339a5','Ashley Martinez','Ms.','Chief Customer Officer','ashley.martinez@example.com','Customer','CU001','+1-800-555-1201',1,NULL,1718811034,'admin',1718811034,'admin'),('deaef0452e5011ef91a300ff079339a5','5d8f899e2e5011ef91a300ff079339a5','Emma Adams','Ms.','Chief Sustainability Officer','emma.adams@example.com','Sustainability','SU001','+1-800-555-2601',1,NULL,1718811034,'admin',1718811034,'admin'),('deaef1192e5011ef91a300ff079339a5','5d8fa01e2e5011ef91a300ff079339a5','Joshua Rodriguez','Mr.','Chief Development Officer','joshua.rodriguez@example.com','Development','DE001','+1-800-555-1301',0,NULL,1718811034,'admin',1718811034,'admin'),('deaef1622e5011ef91a300ff079339a5','5d8fa4f02e5011ef91a300ff079339a5','Kevin Martinez','Mr.','Chief Quality Officer','kevin.martinez@example.com','Quality','QU001','+1-800-555-2701',0,NULL,1718811034,'admin',1718811034,'admin'),('deaef20b2e5011ef91a300ff079339a5','5d8fa4f02e5011ef91a300ff079339a5','Brittany Moore','Ms.','Chief Innovation Officer','brittany.moore@example.com','Innovation','IN001','+1-800-555-1401',1,NULL,1718811034,'admin',1718811034,'admin'),('deaef2792e5011ef91a300ff079339a5','5d8fa4f02e5011ef91a300ff079339a5','Anna Nelson','Ms.','Chief Risk Officer','anna.nelson@example.com','Risk','RI001','+1-800-555-2801',1,NULL,1718811034,'admin',1718811034,'admin'),('deaef3072e5011ef91a300ff079339a5','5d8fa7822e5011ef91a300ff079339a5','Ethan Hall','Mr.','Chief Procurement Officer','ethan.hall@example.com','Procurement','PC001','+1-800-555-1501',0,NULL,1718811034,'admin',1718811034,'admin'),('deaef38f2e5011ef91a300ff079339a5','5d8fa7822e5011ef91a300ff079339a5','Jonathan Lee','Mr.','Chief Operations Officer','jonathan.lee@example.com','Operations','OP002','+1-800-555-2901',0,NULL,1718811034,'admin',1718811034,'admin'),('deaef4022e5011ef91a300ff079339a5','6d8fb9de2e5011ef91a300ff079339a5','Elizabeth Allen','Ms.','Chief Research Officer','elizabeth.allen@example.com','Research','RE001','+1-800-555-1601',1,NULL,1718811034,'admin',1718811034,'admin'),('deaef45a2e5011ef91a300ff079339a5','6d8fbc0e2e5011ef91a300ff079339a5','William King','Mr.','Chief Executive Officer','william.king@example.com','Executive','EX001','+1-800-555-0101',0,NULL,1718811034,'admin',1718811034,'admin'),('deaef5122e5011ef91a300ff079339a5','6d8fbc0e2e5011ef91a300ff079339a5','Nicholas Scott','Mr.','Chief Administrative Officer','nicholas.scott@example.com','Administration','AD001','+1-800-555-1701',0,NULL,1718811034,'admin',1718811034,'admin'),('deaef54b2e5011ef91a300ff079339a5','6d8fbe322e5011ef91a300ff079339a5','Jessica Adams','Ms.','Chief Financial Officer','jessica.adams@example.com','Finance','FI002','+1-800-555-0201',1,NULL,1718811034,'admin',1718811034,'admin'),('deaef6182e5011ef91a300ff079339a5','6d8fbe322e5011ef91a300ff079339a5','Samantha Young','Ms.','Chief Data Officer','samantha.young@example.com','Data','DA001','+1-800-555-1801',1,NULL,1718811034,'admin',1718811034,'admin'),('deaef6342e5011ef91a300ff079339a5','6d8fc0422e5011ef91a300ff079339a5','Christopher Wright','Mr.','Chief Operating Officer','christopher.wright@example.com','Operations','OP001','+1-800-555-0301',0,NULL,1718811034,'admin',1718811034,'admin'),('deaef7192e5011ef91a300ff079339a5','6d8fc0422e5011ef91a300ff079339a5','Paul Gonzalez','Mr.','Chief Information Security Officer','paul.gonzalez@example.com','Information Security','IS001','+1-800-555-1901',0,NULL,1718811034,'admin',1718811034,'admin'),('deaef7212e5011ef91a300ff079339a5','6d8fc2522e5011ef91a300ff079339a5','Amanda Lee','Ms.','Chief Marketing Officer','amanda.lee@example.com','Marketing','MA001','+1-800-555-0401',1,NULL,1718811034,'admin',1718811034,'admin'),('deaef8172e5011ef91a300ff079339a5','6d8fc4622e5011ef91a300ff079339a5','Andrew Harris','Mr.','Chief Information Officer','andrew.harris@example.com','Information Technology','IT001','+1-800-555-0501',0,NULL,1718811034,'admin',1718811034,'admin'),('deaef8232e5011ef91a300ff079339a5','6d8fc4622e5011ef91a300ff079339a5','Jennifer King','Ms.','Chief Analytics Officer','jennifer.king@example.com','Analytics','AN001','+1-800-555-2001',1,NULL,1718811034,'admin',1718811034,'admin'),('deaef9112e5011ef91a300ff079339a5','6d8fc4622e5011ef91a300ff079339a5','Sarah White','Ms.','Chief Human Resources Officer','sarah.white@example.com','Human Resources','HR001','+1-800-555-0601',1,NULL,1718811034,'admin',1718811034,'admin'),('deaef9292e5011ef91a300ff079339a5','6d8fc6722e5011ef91a300ff079339a5','Justin Perez','Mr.','Chief Sales Officer','justin.perez@example.com','Sales','SA002','+1-800-555-2101',0,NULL,1718811034,'admin',1718811034,'admin'),('deaefa0a2e5011ef91a300ff079339a5','6d8fc6722e5011ef91a300ff079339a5','Matthew Clark','Mr.','Chief Legal Officer','matthew.clark@example.com','Legal','LE001','+1-800-555-0701',0,NULL,1718811034,'admin',1718811034,'admin'),('deaefa112e5011ef91a300ff079339a5','6d8fc8822e5011ef91a300ff079339a5','Stephanie White','Ms.','Chief Manufacturing Officer','stephanie.white@example.com','Manufacturing','MN001','+1-800-555-2201',1,NULL,1718811034,'admin',1718811034,'admin'),('deaefb042e5011ef91a300ff079339a5','6d8fc8822e5011ef91a300ff079339a5','Megan Lewis','Ms.','Chief Compliance Officer','megan.lewis@example.com','Compliance','CO001','+1-800-555-0801',1,NULL,1718811034,'admin',1718811034,'admin'),('deaefb222e5011ef91a300ff079339a5','6d8fca922e5011ef91a300ff079339a5','Mark Thompson','Mr.','Chief Communications Officer','mark.thompson@example.com','Communications','CM001','+1-800-555-2301',0,NULL,1718811034,'admin',1718811034,'admin'),('deaefbfa2e5011ef91a300ff079339a5','6d8fca922e5011ef91a300ff079339a5','Brandon Walker','Mr.','Chief Strategy Officer','brandon.walker@example.com','Strategy','ST001','+1-800-555-0901',0,NULL,1718811034,'admin',1718811034,'admin'),('deaefc142e5011ef91a300ff079339a5','6d8fca922e5011ef91a300ff079339a5','Laura Taylor','Ms.','Chief Networking Officer','laura.taylor@example.com','Networking','NW001','+1-800-555-2401',1,NULL,1718811034,'admin',1718811034,'admin'),('deaefcfa2e5011ef91a300ff079339a5','6d8fccb22e5011ef91a300ff079339a5','Emily Robinson','Ms.','Chief Technology Officer','emily.robinson@example.com','Technology','TE001','+1-800-555-1001',1,NULL,1718811034,'admin',1718811034,'admin'),('deaeff1a2e5011ef91a300ff079339a5','6d8fccb22e5011ef91a300ff079339a5','Ryan Hernandez','Mr.','Chief Product Officer','ryan.hernandez@example.com','Product','PR001','+1-800-555-1101',0,NULL,1718811034,'admin',1718811034,'admin'),('deaeff2e2e5011ef91a300ff079339a5','6d8fccb22e5011ef91a300ff079339a5','Thomas Baker','Mr.','Chief Experience Officer','thomas.baker@example.com','Experience','EX002','+1-800-555-2501',0,NULL,1718811034,'admin',1718811034,'admin');
/*!40000 ALTER TABLE `customer_company_contact_person` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-28 22:11:47
