-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tariff_cleaning`
--

DROP TABLE IF EXISTS `tariff_cleaning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tariff_cleaning` (
  `guid` varchar(36) NOT NULL,
  `cleaning_method_guid` varchar(36) DEFAULT NULL,
  `cleaning_category_guid` varchar(36) DEFAULT NULL,
  `msds_guid` varchar(36) DEFAULT NULL,
  `cargo` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `un_no` varchar(45) DEFAULT NULL,
  `class_cv` varchar(20) DEFAULT NULL,
  `flash_point` int DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `hazard_level_cv` varchar(20) DEFAULT NULL,
  `ban_type_cv` varchar(20) DEFAULT NULL,
  `nature_cv` varchar(20) DEFAULT NULL,
  `open_on_gate_cv` varchar(20) DEFAULT NULL,
  `in_gate_alert` varchar(45) DEFAULT NULL,
  `depot_note` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `update_dt` bigint DEFAULT NULL,
  `update_by` varchar(45) DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tariff_cleaning`
--

LOCK TABLES `tariff_cleaning` WRITE;
/*!40000 ALTER TABLE `tariff_cleaning` DISABLE KEYS */;
INSERT INTO `tariff_cleaning` VALUES ('1a2548b7438043749053ffcf750ca0e2','05a2e4db04ed477ca22f9a98cc408c9b','8620aa3a32d3447cbfa33f74b11a862a',NULL,'Cargo 1','a','-','2',21,'Easy M1','hazard level 1','ban','n','Y','alert','note','remark 123',1719471677,'anonymous user',1719470875,'anonymous user',1719471677),('1fc189c899ba4bac8935405e06fa08f4','17644c4c93504215aea1ba089e646243','57d5f47af59b498ab0629d383c969e0d',NULL,'cargo123','','UN5789','1.6',323,'','ACUTE_TOXICITY',NULL,'GASES','N','utyu','',NULL,NULL,NULL,1726324047,'anonymous user',NULL),('2b4f5678f89c23d4b567536725285014','05a2e4db04ed477ca22f9a98cc408c9b','8620aa3a32d3447cbfa33f74b11a862a',NULL,'(1-methylethylidene)di-4,1-phenylenetetraphenyl diphosphate','','302854','2.2',110,'Flame Retardants','FLAMMABLE','Ban B','FLAMABLE','N','Alert B','Depot Note B','Remarks B',1725024599,'anonymous user',1625151600,'user2',NULL),('3a2ebfedb0c6419daafa6bd168415d17','2753527301604e75a16c09f61fa887f5','57d5f47af59b498ab0629d383c969e0d',NULL,'cargo 1234','','UN4355','2.2',4,'','HAZARDOUS',NULL,'HAZARDOUS','Y','yrer','',NULL,NULL,NULL,1726323821,'anonymous user',NULL),('3c5g6789g89d34e5c678646836396017','0ac3f34c777445caa63766206a6d7f63','8620aa3a32d3447cbfa33f74b11a862a',NULL,'(1-Phenylethyl)Xylene','Alias C','1245','2.1',120,'Solvent in chemical processes','IRRITANT','Ban C','HAZARDOUS','N','Alert C','Depot Note','Remarks C',1725097178,'anonymous user',1625238000,'user3',NULL),('4d18e88e2ecb4412b673afa37a39cd26','05a2e4db04ed477ca22f9a98cc408c9b','6342cef5aadb4402bcdfbaed0de21c0b',NULL,'cargo 456','','UN4424','1.6',4,'','ACUTE_TOXICITY',NULL,'GASES','Y','4645','',NULL,NULL,NULL,1726324328,'anonymous user',NULL),('656a5ef643f349d0b8fb7471febf6758','17644c4c93504215aea1ba089e646243','57d5f47af59b498ab0629d383c969e0d',NULL,'(Dehydol) Alcohol C12-C15 Poly (1-6) Ethoxylate',NULL,'UN3082','2.2',23,'Household Cleaning Product','ORGANIC_PEROXIDES','FULL_BAN','TOXIC','N','Alert 1','-',NULL,1721282209,'anonymous user',1720917010,'anonymous user',NULL),('6f1m2345m45j90k1i234291492952041','6429c659d2e646d58d515482c43b25df','8620aa3a32d3447cbfa33f74b11a862a',NULL,'0 0-Diethyl-O-(2-Chloro-4-Bromo) Phenyl Phosphorodithioate','Alias I','UN3018','8',180,'Insecticide or Pesticide','ACUTE_TOXICITY','Ban I','TOXIC','N','Alert I','Depot Note I','Remarks I',1721282221,'anonymous user',1625756400,'user9',NULL),('737436b96fe34896a0056e4037444b09','8f4b4c2e54c944b4aaca233dc9a4bdf3','8620aa3a32d3447cbfa33f74b11a862a',NULL,'22-Dichoropropane','','UN2567','6.1',154,'1 2-Dichoropropane -1231','HAZARDOUS',NULL,'FLAMABLE','Y','test','',NULL,1726323341,'anonymous user',1726323057,'anonymous user',NULL),('7a0l1234l34i89j0h123190381841037','78bc7e9e82c14a6b8f5eef56ab5ad05b','ff4170239a2845e8be7a59bb2c14ca6c',NULL,'01N_Butyl Acetate','Alias H','1235','2.3',170,'Solvent','ASPIRATION_TOXICITY','Ban H','FLAMABLE','N','Alert H','Depot Note H','Remarks H',1721450270,'anonymous user',1625670000,'user8',NULL),('822d13d0bccc4018b88d3124354c2cad','78bc7e9e82c14a6b8f5eef56ab5ad05b','ff4170239a2845e8be7a59bb2c14ca6c',NULL,'(3-Chloro-2-Hydroxypropyl) Trime-Ammonium Chloride (PTAC 69%)','alias name 123','UN1714','4.1',122,'Ammonium Compound','EXPLOSIVES',NULL,'FLAMMABLE','N','Smelly','High Flash Point','Remarks Test 2',1727220081,'anonymous user',1721067375,'anonymous user',NULL),('85ee69e0504e44b5895f30ede2262019','2753527301604e75a16c09f61fa887f5','a2a655d27ca94b3ebcc41f3413ba412e',NULL,'cargo 678','','UN4586','1.5',321,'','PRESURE_GASES',NULL,'GASES','Y','y75','',NULL,NULL,NULL,1726324217,'anonymous user',NULL),('8b9k0123k23h78i9g012089270730033','7f8fafe54b01460fa695edb112cc0350','a2a655d27ca94b3ebcc41f3413ba412e',NULL,'0406_4','','UN9003','4.1',160,'','OXIDIZER','Ban G','GASES','Y','Alert G','Depot Note G','Remarks G',1726323421,'anonymous user',1625583600,'user7',NULL),('905bdeb6ff4b4cb0aab3b45f9d92cf35','0ac3f34c777445caa63766206a6d7f63','37af3c367ae547018fc1b7d3f0d5b94f',NULL,'083 Line AD Rock (On Trial - FMO High)','','UN0078','1.5',45,'','FLAMMABLE','FULL_BAN','FLAMABLE','N','Alert 587','',NULL,1727012816,'anonymous user',1720922641,'anonymous user',NULL),('9c8j9012j12g67h8f901978169629029','17644c4c93504215aea1ba089e646243','0753dfa8e33c425584b905c3649019fa',NULL,'1 3-Phenylenediamine (Banned Cargo)','Alias F','UN1673','6.1',150,'Aromatic Amine Compound','ORGANIC_PEROXIDES','Ban F','GASES','N','Banned Cargo','Depot Note F','Remarks F',1721282007,'anonymous user',1625497200,'user6',NULL),('a17i8901i01f56g7e890867058518025','05a2e4db04ed477ca22f9a98cc408c9b','8620aa3a32d3447cbfa33f74b11a862a',NULL,'1 4 Butanol','','UN1120','3.5',140,'Alchohol','FLAMMABLE','Ban E','FLAMABLE','Y','Alert E','Depot Note E','Remarks E',1721282085,'anonymous user',1625410800,'user5',NULL),('b23e4567e89b12d3a456426614174101','bddb976068ee49868dd8c099d1eca424','123e4567e89b12d3a4564266141741fc',NULL,'1 2 4-Trichlorobenzene','Alias A','UN2321','6.1',100,'','ACUTE_TOXICITY','Ban A','TOXIC','N','Alert A','Depot Note A','Remarks A',1725157016,'anonymous user',1625075200,'user1',NULL),('c36h7890h90e45f6d789756947407021','bddb976068ee49868dd8c099d1eca424','8620aa3a32d3447cbfa33f74b11a862a',NULL,'1 2 4-Trimethylbenzene','Alias D','UN2325','3',130,'Aromatic Hydrocarbon','FLAMMABLE','Ban D','FLAMABLE','N','Alert D','Depot Note D','Remarks D',1727267165,'anonymous user',1625324400,'user4',NULL),('c478635307e84b08b84b9a873192d58e','78bc7e9e82c14a6b8f5eef56ab5ad05b','ff4170239a2845e8be7a59bb2c14ca6c',NULL,'1 2-Benzisothiazolin-3-One','','UN3077','1.6',434,' Preservative and Biocide','HAZARDOUS',NULL,'HAZARDOUS','N','Special Handle','New Tank Type',NULL,1725156905,'anonymous user',1721130316,'anonymous user',NULL),('d2f3e443dc844da7b261561059bda975','b19c4a81f49e47699f15b6ed964ca13b','6342cef5aadb4402bcdfbaed0de21c0b',NULL,'1 2-Dichoropropane','','UN2369','3',34,'Cargo Special','FLAMMABLE','FULL_BAN','GASES','Y','Alert 500','',NULL,1725156808,'anonymous user',1720922597,'anonymous user',NULL),('d30a86fc92994331be3f9015feb24574','2753527301604e75a16c09f61fa887f5','57d5f47af59b498ab0629d383c969e0d',NULL,'Cargo 9865','','UN9875','3',3232,'','FLAMMABLE',NULL,'FLAMABLE','Y','5454','',NULL,NULL,NULL,1726324438,'anonymous user',NULL),('db5a33d19a5d468f84f8c3ae287d5404','6429c659d2e646d58d515482c43b25df','ff4170239a2845e8be7a59bb2c14ca6c',NULL,'Ethanol test flash point 0','test flash point 0','UN6473','4.1',-43,'Ethanol test flash point 0','EXPLOSIVES',NULL,'FLAMABLE','N','test flash point 0','',NULL,1723306848,'anonymous user',1721452241,'anonymous user',NULL);
/*!40000 ALTER TABLE `tariff_cleaning` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-28 22:11:45
