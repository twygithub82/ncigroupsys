-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `guid` varchar(36) NOT NULL,
  `id` int DEFAULT NULL,
  `notification_uid` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL COMMENT 'link to repair table',
  `date` bigint DEFAULT NULL,
  `is_read` tinyint DEFAULT NULL,
  `type_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = NOTIFICATION_TYPE',
  `module_cv` varchar(50) DEFAULT NULL COMMENT 'code_val_type = NOTIFICATION_MODULE',
  `update_dt` bigint DEFAULT NULL,
  `update_by` varchar(45) DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES ('1dc049b09c854fa6acace55953ab21a7',3,'cc-booking-ASDF 394758-1',NULL,'booking record for ASDF 394758-1 not tally with scheduling',1726301434,NULL,NULL,'cross-check-booking',NULL,NULL,1726301434,'anonymous user',NULL),('28cac373ef0c4be490ed35075b25927d',3,'cc-scheduling-',NULL,'Operation forgot to schedule:',1726320622,NULL,NULL,'cross-check-scheduling',NULL,NULL,1726320622,'anonymous user',NULL),('2c015d094cbe498c863bce11b91a712e',3,'cc-booking-',NULL,'Commercial forgot to book:',1726321089,NULL,NULL,'cross-check-booking',NULL,NULL,1726321089,'anonymous user',NULL),('2c7815e70c9442968332410eb19b5e78',3,'cc-scheduling-',NULL,'Operation forgot to schedule:',1726318236,NULL,NULL,'cross-check-scheduling',NULL,NULL,1726318236,'anonymous user',NULL),('40795bfedfc340dc929faf6ad10898a6',3,'cc-scheduling-',NULL,'Operation forgot to schedule:',1726321203,NULL,NULL,'cross-check-scheduling',NULL,NULL,1726321203,'anonymous user',NULL),('4ca7f44c2c004b378f25f1997a467fb4',3,'cc-scheduling-',NULL,'Operation forgot to schedule:',1726318236,NULL,NULL,'cross-check-scheduling',NULL,NULL,1726318236,'anonymous user',NULL),('4cc1ee6bf02f4391a6aa92e5f632b034',3,'cc-booking-',NULL,'Commercial forgot to book:',1726321203,NULL,NULL,'cross-check-booking',NULL,NULL,1726321203,'anonymous user',NULL),('5229e7e2aa9e4f359c4464aa73a8e74c',3,'cc-booking-',NULL,'Commercial forgot to book:',1726318236,NULL,NULL,'cross-check-booking',NULL,NULL,1726318236,'anonymous user',NULL),('5507d54e611a4f1889c2a98e8e3c352c',3,'cc-booking-',NULL,'Commercial forgot to book:',1726318236,NULL,NULL,'cross-check-booking',NULL,NULL,1726318236,'anonymous user',NULL),('574a6c976cae464792a9a88e60ebac13',3,'cc-booking-',NULL,'Commercial forgot to book:',1726320781,NULL,NULL,'cross-check-booking',NULL,NULL,1726320781,'anonymous user',NULL),('57b98941f8274d62aadb918a6c50cca1',3,'cc-booking-',NULL,'Commercial forgot to book:',1726321049,NULL,NULL,'cross-check-booking',NULL,NULL,1726321049,'anonymous user',NULL),('599344359feb46f0a22a3f0966c96ee0',3,'cc-scheduling-',NULL,'Operation forgot to schedule:',1726321142,NULL,NULL,'cross-check-scheduling',NULL,NULL,1726321142,'anonymous user',NULL),('68ce539dd152435b89ba87b99d9bbdcc',3,'cc-scheduling-',NULL,'Operation forgot to schedule:',1726321049,NULL,NULL,'cross-check-scheduling',NULL,NULL,1726321049,'anonymous user',NULL),('695cfe7f11e5493abd60cc3a4ba5120f',3,'cc-booking-',NULL,'Commercial forgot to book:',1726321142,NULL,NULL,'cross-check-booking',NULL,NULL,1726321142,'anonymous user',NULL),('7d45ad3f6819467e96a2f114827db636',3,'cc-scheduling-',NULL,'Operation forgot to schedule:',1726321089,NULL,NULL,'cross-check-scheduling',NULL,NULL,1726321089,'anonymous user',NULL),('7f0b1031fcda401a93d6f44110f57427',3,'cc-booking-ASDF 394758-1',NULL,'Commercial forgot to book:ASDF 394758-1',1726301433,NULL,NULL,'cross-check-booking',NULL,NULL,1726301433,'anonymous user',NULL),('819f908f36c5495abfc3a836af6c8e31',3,'cc-booking-',NULL,'Commercial forgot to book:',1726320781,NULL,NULL,'cross-check-booking',NULL,NULL,1726320781,'anonymous user',NULL),('83f07b14af6d4a248c6a17bd14e2e997',3,'cc-booking-',NULL,'Commercial forgot to book:',1726321049,NULL,NULL,'cross-check-booking',NULL,NULL,1726321049,'anonymous user',NULL),('88e480b1490c4f058a2340aa9733b87e',3,'cc-booking-',NULL,'Commercial forgot to book:',1726321142,NULL,NULL,'cross-check-booking',NULL,NULL,1726321142,'anonymous user',NULL),('89aa28d7853446798d4f8d53c5fc74b2',3,'cc-booking-',NULL,'Commercial forgot to book:',1726321203,NULL,NULL,'cross-check-booking',NULL,NULL,1726321203,'anonymous user',NULL),('8f4af08d95694b82ad8b2449fe937721',3,'cc-scheduling-',NULL,'Operation forgot to schedule:',1726320781,NULL,NULL,'cross-check-scheduling',NULL,NULL,1726320781,'anonymous user',NULL),('96a5fadf12ff4b1385dc1f8166803b1e',3,'cc-scheduling-HBGJ 899421-4',NULL,'Operation forgot to schedule:HBGJ 899421-4',1726301434,NULL,NULL,'cross-check-scheduling',NULL,NULL,1726301434,'anonymous user',NULL),('9d1f1cac55a34c75837dfaa3800a605c',3,'cc-booking-',NULL,'Commercial forgot to book:',1726321089,NULL,NULL,'cross-check-booking',NULL,NULL,1726321089,'anonymous user',NULL),('a0afa4dfabcf4829aacdbaee1af5cda3',3,'cc-scheduling-',NULL,'Operation forgot to schedule:',1726320781,NULL,NULL,'cross-check-scheduling',NULL,NULL,1726320781,'anonymous user',NULL),('a153f8ed7f4843648b7124793568c457',3,'cc-booking-',NULL,'Commercial forgot to book:',1726320622,NULL,NULL,'cross-check-booking',NULL,NULL,1726320622,'anonymous user',NULL),('b3b310ddf0174ef597eff3eb1a3af8b7',3,'cc-scheduling-',NULL,'Operation forgot to schedule:',1726321142,NULL,NULL,'cross-check-scheduling',NULL,NULL,1726321142,'anonymous user',NULL),('c34c267658a14a1b9dc1b7c673a0afc2',3,'cc-booking-',NULL,'Commercial forgot to book:',1726320622,NULL,NULL,'cross-check-booking',NULL,NULL,1726320622,'anonymous user',NULL),('c867dbcec7cc4349a29d9fd1836d71b1',3,'cc-scheduling-ASDF 394758-1',NULL,'scheduling record for ASDF 394758-1 not tally with booking',1726301434,NULL,NULL,'cross-check-scheduling',NULL,NULL,1726301434,'anonymous user',NULL),('cda07688cc2c47e3925599c979c783d2',3,'cc-booking-QWER 874956-1',NULL,'Commercial forgot to book:QWER 874956-1',1726301434,NULL,NULL,'cross-check-booking',NULL,NULL,1726301434,'anonymous user',NULL),('d0fa7c3c45d24fb7b47b2aab0b26d37b',3,'cc-booking-',NULL,'Commercial forgot to book:',1726321089,NULL,NULL,'cross-check-booking',NULL,NULL,1726321089,'anonymous user',NULL),('d469d2241cdb4e4d96be4216aa5ea4d9',3,'cc-booking-',NULL,'Commercial forgot to book:',1726321203,NULL,NULL,'cross-check-booking',NULL,NULL,1726321203,'anonymous user',NULL),('dd968549e58b4114a853f9ec5b9b75fe',3,'cc-booking-',NULL,'Commercial forgot to book:',1726320781,NULL,NULL,'cross-check-booking',NULL,NULL,1726320781,'anonymous user',NULL),('deb8fdc968814c2f9516da14f4b992b4',3,'cc-scheduling-',NULL,'Operation forgot to schedule:',1726321089,NULL,NULL,'cross-check-scheduling',NULL,NULL,1726321089,'anonymous user',NULL),('deca11d2dedd401bbcc76b97247ae049',3,'cc-booking-',NULL,'Commercial forgot to book:',1726321049,NULL,NULL,'cross-check-booking',NULL,NULL,1726321049,'anonymous user',NULL),('df252c5cc1834d419a35abb9390cf8b9',3,'cc-booking-',NULL,'Commercial forgot to book:',1726321142,NULL,NULL,'cross-check-booking',NULL,NULL,1726321142,'anonymous user',NULL),('e21bfdeae7aa44e685efbc72cda629ad',3,'cc-booking-',NULL,'Commercial forgot to book:',1726321142,NULL,NULL,'cross-check-booking',NULL,NULL,1726321142,'anonymous user',NULL),('e6eaddc0db924ba78e407ae4c8f3d8bd',3,'cc-scheduling-',NULL,'Operation forgot to schedule:',1726320622,NULL,NULL,'cross-check-scheduling',NULL,NULL,1726320622,'anonymous user',NULL),('f0e05d15e2b54cc5a0f9057ea4adb3a6',3,'cc-booking-',NULL,'Commercial forgot to book:',1726320622,NULL,NULL,'cross-check-booking',NULL,NULL,1726320622,'anonymous user',NULL),('f1bdea9476324267944429cfb0db09ca',3,'cc-scheduling-',NULL,'Operation forgot to schedule:',1726321203,NULL,NULL,'cross-check-scheduling',NULL,NULL,1726321203,'anonymous user',NULL),('f5430bb1793c47a9a1c411ee23baa5c8',3,'cc-scheduling-',NULL,'Operation forgot to schedule:',1726321049,NULL,NULL,'cross-check-scheduling',NULL,NULL,1726321049,'anonymous user',NULL),('fd9884523b9d4ff0ad5f825ea1e1fac4',3,'cc-booking-',NULL,'Commercial forgot to book:',1726318236,NULL,NULL,'cross-check-booking',NULL,NULL,1726318236,'anonymous user',NULL),('fdef33b3c3db45c590b4c8b331069c00',3,'cc-booking-',NULL,'Commercial forgot to book:',1726321049,NULL,NULL,'cross-check-booking',NULL,NULL,1726321049,'anonymous user',NULL),('fefea0edaeff4870a23630ee0ee1ddfa',3,'cc-booking-HBGJ 899421-4',NULL,'Commercial forgot to book:HBGJ 899421-4',1726301433,NULL,NULL,'cross-check-booking',NULL,NULL,1726301433,'anonymous user',NULL);
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-28 22:11:34
