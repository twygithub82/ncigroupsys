-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `repair_est`
--

DROP TABLE IF EXISTS `repair_est`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repair_est` (
  `guid` varchar(36) NOT NULL,
  `sot_guid` varchar(36) NOT NULL,
  `aspnetusers_guid` varchar(36) NOT NULL,
  `estimate_no` varchar(20) NOT NULL,
  `labour_cost_discount` double NOT NULL DEFAULT '0',
  `material_cost_discount` double NOT NULL DEFAULT '0',
  `labour_cost` double NOT NULL DEFAULT '0',
  `total_cost` double NOT NULL DEFAULT '0',
  `status_cv` varchar(20) NOT NULL COMMENT 'code_val_type = REP_EST_STATUS',
  `remarks` varchar(150) DEFAULT NULL,
  `owner_enable` tinyint NOT NULL DEFAULT '0',
  `update_dt` bigint DEFAULT NULL,
  `update_by` varchar(45) DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  `running_number` int NOT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repair_est`
--

LOCK TABLES `repair_est` WRITE;
/*!40000 ALTER TABLE `repair_est` DISABLE KEYS */;
INSERT INTO `repair_est` VALUES ('69d47665f35e468f88cf6a1a2eb3b4d7','fada38916c82458c96fd9ba238d5ce48','fb980647-fb81-465f-a0d4-28c31701a554','RE24390004',2,10,45,694,'PENDING','This remarks will show at repair estimate',0,1727526315,'anonymous user',1727504588,'anonymous user',NULL,4),('7390e811cce6426caaa23ea9f1b7280b','f3996dad18764c269a8a94301312b983','fb980647-fb81-465f-a0d4-28c31701a554','RE24390001',10,10,45,849,'PENDING','This remarks will show at repair estimate',0,NULL,NULL,1727466189,'anonymous user',NULL,1),('a1ae430c624942b68ede69b1bafbcd3d','459535932b8340b4a572d7aea58bdbad','fb980647-fb81-465f-a0d4-28c31701a554','RE24390002',3,1,45,708,'PENDING','',1,1727275760,'anonymous user',1727185876,'anonymous user',NULL,2),('f958a77a55284e6283590cc9c5088308','4bae13891a9648d7831d17b022b6fff1','fb980647-fb81-465f-a0d4-28c31701a554','RE24390003',0,0,45,102,'PENDING','',0,NULL,NULL,1727467291,'anonymous user',NULL,3);
/*!40000 ALTER TABLE `repair_est` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`idms_admin`@`%`*/ /*!50003 TRIGGER `trg_before_insert_repair_est` BEFORE INSERT ON `repair_est` FOR EACH ROW BEGIN
    DECLARE max_number INT;
    DECLARE current_year CHAR(2);
    DECLARE current_week CHAR(2);
    DECLARE current_dt DATETIME;

    -- Convert epoch time to datetime
    SET current_dt = FROM_UNIXTIME(NEW.create_dt);

    -- Get the current year and week number
    SET current_year = DATE_FORMAT(current_dt, '%y');
    SET current_week = LPAD(WEEK(current_dt, 1), 2, '0'); -- ISO week

    -- Get the current maximum running number for the year and week
    SELECT COALESCE(MAX(running_number), 0) + 1 INTO max_number
    FROM repair_est
    WHERE YEAR(FROM_UNIXTIME(create_dt)) = YEAR(current_dt)
    AND WEEK(FROM_UNIXTIME(create_dt), 1) = WEEK(current_dt, 1);

    -- Set the running number
    SET NEW.running_number = max_number;

    -- Generate the RO_NO
    SET NEW.estimate_no = CONCAT('RE', current_year, current_week, LPAD(max_number, 4, '0'));
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-28 22:11:41
