-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cleaning_method`
--

DROP TABLE IF EXISTS `cleaning_method`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cleaning_method` (
  `guid` varchar(36) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(45) DEFAULT NULL,
  `sequence` int DEFAULT NULL,
  `update_dt` bigint DEFAULT NULL,
  `update_by` varchar(45) DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cleaning_method`
--

LOCK TABLES `cleaning_method` WRITE;
/*!40000 ALTER TABLE `cleaning_method` DISABLE KEYS */;
INSERT INTO `cleaning_method` VALUES ('05a2e4db04ed477ca22f9a98cc408c9b','METHOD1','Method 1',1,1719371441,'anonymous user',1719208729,'anonymous user',NULL),('0ac3f34c777445caa63766206a6d7f63','METHOD2','Method 2',2,1719371579,'anonymous user',1719208711,'anonymous user',NULL),('123e4567e89b12d3a456426614174101','METHOD10','Method 10',10,1625151600,'user1',1625075200,'user1',NULL),('17644c4c93504215aea1ba089e646243','METHOD3','Method 3',3,1719373845,'anonymous user',1719208639,'anonymous user',NULL),('234f5678f89c23d4b567536725285014','METHOD11','Method 11',11,1625238000,'user2',1625151600,'user2',NULL),('2753527301604e75a16c09f61fa887f5','METHOD4','Method 4',4,1719374525,'anonymous user',1719374345,'anonymous user',NULL),('6429c659d2e646d58d515482c43b25df','METHOD5','Method 5',5,1719209298,'anonymous user',1719208785,'anonymous user',NULL),('78bc7e9e82c14a6b8f5eef56ab5ad05b','METHOD6','Method 6',6,1719374242,'anonymous user',1719208617,'anonymous user',NULL),('7f8fafe54b01460fa695edb112cc0350','METHOD7','Method 7',7,1719374306,'anonymous user',1719208757,'anonymous user',NULL),('8f4b4c2e54c944b4aaca233dc9a4bdf3','METHOD15','method 15',NULL,NULL,NULL,1724072980,'anonymous user',NULL),('b19c4a81f49e47699f15b6ed964ca13b','METHOD8','Method 8',8,1719374256,'anonymous user',1719208771,'anonymous user',NULL),('bddb976068ee49868dd8c099d1eca424','METHOD9','Method 9',9,1719374276,'anonymous user',1719208743,'anonymous user',NULL);
/*!40000 ALTER TABLE `cleaning_method` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-28 22:12:05
