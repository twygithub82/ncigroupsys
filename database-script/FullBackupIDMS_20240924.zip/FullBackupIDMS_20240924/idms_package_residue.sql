-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `package_residue`
--

DROP TABLE IF EXISTS `package_residue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `package_residue` (
  `guid` varchar(36) NOT NULL,
  `tariff_residue_guid` varchar(36) DEFAULT NULL,
  `customer_company_guid` varchar(36) DEFAULT NULL,
  `cost` double DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `update_dt` bigint DEFAULT NULL,
  `update_by` varchar(45) DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package_residue`
--

LOCK TABLES `package_residue` WRITE;
/*!40000 ALTER TABLE `package_residue` DISABLE KEYS */;
INSERT INTO `package_residue` VALUES ('055d554669654fa19adaa152dd95d8c6','c0445f83a591482cbd5cf444b6e6aacd','6d8fc2522e5011ef91a300ff079339a5',60,'re',NULL,NULL,1723730009,'anonymous user',NULL),('163821746f8a43a3a9404ba76a305a6d','c0445f83a591482cbd5cf444b6e6aacd','5d8f899e2e5011ef91a300ff079339a5',60,'re',NULL,NULL,1723730009,'anonymous user',NULL),('1da87f8b7c9a4332a5bea0b6235326b1','c0445f83a591482cbd5cf444b6e6aacd','6d8fca922e5011ef91a300ff079339a5',60,'re',NULL,NULL,1723730009,'anonymous user',NULL),('26fb61de12c84030ab0079cee144e163','c0445f83a591482cbd5cf444b6e6aacd','6d8fc6722e5011ef91a300ff079339a5',68,'re',1725092997,'anonymous user',1723730009,'anonymous user',NULL),('2bb762953f0d4681b9648072af16892e','c0445f83a591482cbd5cf444b6e6aacd','5d8fa7822e5011ef91a300ff079339a5',60,'re',NULL,NULL,1723730009,'anonymous user',NULL),('2df768c4f173431fa5583525c6803a61','c0445f83a591482cbd5cf444b6e6aacd','6d8fbe322e5011ef91a300ff079339a5',60,'re',NULL,NULL,1723730009,'anonymous user',NULL),('2e3725d6d6af43d584f9d3482c1f044d','c0445f83a591482cbd5cf444b6e6aacd','5d8fa4f02e5011ef91a300ff079339a5',60,'re',NULL,NULL,1723730009,'anonymous user',NULL),('4536f6e6b943403b98b0bbc9892d1a8d','c0445f83a591482cbd5cf444b6e6aacd','6d8fbc0e2e5011ef91a300ff079339a5',60,'re',NULL,NULL,1723730009,'anonymous user',NULL),('65faa9de71fa11ef8d4b6045bd5acb12','eb61a4f1899f4d8484dfd9e47dd39a50','5d8f899e2e5011ef91a300ff079339a5',5,'Include Harden Liquid',NULL,NULL,1726250573,'anonymous user',NULL),('65faad4e71fa11ef8d4b6045bd5acb12','eb61a4f1899f4d8484dfd9e47dd39a50','5d8fa01e2e5011ef91a300ff079339a5',5,'Include Harden Liquid',NULL,NULL,1726250573,'anonymous user',NULL),('65faaeb571fa11ef8d4b6045bd5acb12','eb61a4f1899f4d8484dfd9e47dd39a50','5d8fa4f02e5011ef91a300ff079339a5',5,'Include Harden Liquid',NULL,NULL,1726250573,'anonymous user',NULL),('65faafdd71fa11ef8d4b6045bd5acb12','eb61a4f1899f4d8484dfd9e47dd39a50','5d8fa7822e5011ef91a300ff079339a5',5,'Include Harden Liquid',NULL,NULL,1726250573,'anonymous user',NULL),('65fab0ed71fa11ef8d4b6045bd5acb12','eb61a4f1899f4d8484dfd9e47dd39a50','5d8faa9d2e5011ef91a300ff079339a5',5,'Include Harden Liquid',NULL,NULL,1726250573,'anonymous user',NULL),('65fab87771fa11ef8d4b6045bd5acb12','eb61a4f1899f4d8484dfd9e47dd39a50','6d8fb9de2e5011ef91a300ff079339a5',5,'Include Harden Liquid',NULL,NULL,1726250573,'anonymous user',NULL),('65fac89171fa11ef8d4b6045bd5acb12','eb61a4f1899f4d8484dfd9e47dd39a50','6d8fbc0e2e5011ef91a300ff079339a5',5,'Include Harden Liquid',NULL,NULL,1726250573,'anonymous user',NULL),('65faca1a71fa11ef8d4b6045bd5acb12','eb61a4f1899f4d8484dfd9e47dd39a50','6d8fbe322e5011ef91a300ff079339a5',5,'Include Harden Liquid',NULL,NULL,1726250573,'anonymous user',NULL),('65facb2271fa11ef8d4b6045bd5acb12','eb61a4f1899f4d8484dfd9e47dd39a50','6d8fc0422e5011ef91a300ff079339a5',5,'Include Harden Liquid',NULL,NULL,1726250573,'anonymous user',NULL),('65facc2771fa11ef8d4b6045bd5acb12','eb61a4f1899f4d8484dfd9e47dd39a50','6d8fc2522e5011ef91a300ff079339a5',5,'Include Harden Liquid',NULL,NULL,1726250573,'anonymous user',NULL),('65facd2571fa11ef8d4b6045bd5acb12','eb61a4f1899f4d8484dfd9e47dd39a50','6d8fc4622e5011ef91a300ff079339a5',5,'Include Harden Liquid',NULL,NULL,1726250573,'anonymous user',NULL),('65face2771fa11ef8d4b6045bd5acb12','eb61a4f1899f4d8484dfd9e47dd39a50','6d8fc6722e5011ef91a300ff079339a5',5,'Include Harden Liquid',NULL,NULL,1726250573,'anonymous user',NULL),('65facf2971fa11ef8d4b6045bd5acb12','eb61a4f1899f4d8484dfd9e47dd39a50','6d8fc8822e5011ef91a300ff079339a5',5,'Include Harden Liquid',NULL,NULL,1726250573,'anonymous user',NULL),('65fad02971fa11ef8d4b6045bd5acb12','eb61a4f1899f4d8484dfd9e47dd39a50','6d8fca922e5011ef91a300ff079339a5',5,'Include Harden Liquid',NULL,NULL,1726250573,'anonymous user',NULL),('65fad16f71fa11ef8d4b6045bd5acb12','eb61a4f1899f4d8484dfd9e47dd39a50','6d8fccb22e5011ef91a300ff079339a5',5,'Include Harden Liquid',NULL,NULL,1726250573,'anonymous user',NULL),('95cb6deb41b248db9d5f6246f9aeba10','c0445f83a591482cbd5cf444b6e6aacd','5d8fa01e2e5011ef91a300ff079339a5',60,'re',NULL,NULL,1723730009,'anonymous user',NULL),('997749e0aef34d9280148c0c18564b34','c0445f83a591482cbd5cf444b6e6aacd','6d8fb9de2e5011ef91a300ff079339a5',60,'re',NULL,NULL,1723730009,'anonymous user',NULL),('abff3997759f409ea09cc35ceb6c30ad','c0445f83a591482cbd5cf444b6e6aacd','6d8fccb22e5011ef91a300ff079339a5',60,'re',NULL,NULL,1723730009,'anonymous user',NULL),('ae379f18a3f641bcae39a63740ec7703','c0445f83a591482cbd5cf444b6e6aacd','6d8fc4622e5011ef91a300ff079339a5',68,'re',1725092997,'anonymous user',1723730009,'anonymous user',NULL),('b9dd7406d49c4f2e891d74a7855d0e57','c0445f83a591482cbd5cf444b6e6aacd','5d8faa9d2e5011ef91a300ff079339a5',60,'re',NULL,NULL,1723730009,'anonymous user',NULL),('d0a055912d0548b0b2cc50f0faad8336','c0445f83a591482cbd5cf444b6e6aacd','6d8fc0422e5011ef91a300ff079339a5',60,'re',NULL,NULL,1723730009,'anonymous user',NULL),('edde36cd480d4f7baab567cda840546d','c0445f83a591482cbd5cf444b6e6aacd','6d8fc8822e5011ef91a300ff079339a5',60,'re',NULL,NULL,1723730009,'anonymous user',NULL);
/*!40000 ALTER TABLE `package_residue` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-24 21:53:32
