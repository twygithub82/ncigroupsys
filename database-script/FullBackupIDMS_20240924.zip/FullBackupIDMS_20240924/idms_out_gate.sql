-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `out_gate`
--

DROP TABLE IF EXISTS `out_gate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `out_gate` (
  `guid` varchar(36) NOT NULL,
  `so_tank_guid` varchar(36) DEFAULT NULL,
  `eir_no` varchar(36) DEFAULT NULL,
  `eir_dt` bigint DEFAULT NULL,
  `eir_status_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = EIR_STATUS',
  `vehicle_no` varchar(20) DEFAULT NULL,
  `driver_name` varchar(120) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `update_dt` bigint DEFAULT NULL,
  `update_by` varchar(45) DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  `running_number` int NOT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `out_gate`
--

LOCK TABLES `out_gate` WRITE;
/*!40000 ALTER TABLE `out_gate` DISABLE KEYS */;
INSERT INTO `out_gate` VALUES ('028a97eba829440b9555568385ec2aa1','92f68b9594d247d8aebf1430194f0c96','RO24350001-0003',1724700241,'YET_TO_SURVEY','EGG8395E','Ah Dee','Carry 2 tank',1724700241,'anonymous user',NULL,NULL,NULL,3),('09b726c257634cd98c49feb8fcb8766d','92f68b9594d247d8aebf1430194f0c96','RO24350001-0001',1724700224,'YET_TO_SURVEY','EGG8395E','Ah Dee','Carry 2 tank',1724700224,'anonymous user',NULL,NULL,NULL,1),('0a4cc9a6633c4f11b37c225b41022147','92f68b9594d247d8aebf1430194f0c96','RO24350001-0010',1724700288,'YET_TO_SURVEY','EGG8395E','Ah Dee','Carry 2 tank',1724700288,'anonymous user',NULL,NULL,NULL,10),('21e67883d2124af195583672aa4676da','92f68b9594d247d8aebf1430194f0c96','RO24350001-0002',1724700228,'YET_TO_SURVEY','EGG8395E','Ah Dee','Carry 2 tank',1724700228,'anonymous user',NULL,NULL,NULL,2),('3b473c0929ec4ac4af83dac9c9833906','92f68b9594d247d8aebf1430194f0c96','RO24350001-0005',1724700283,'YET_TO_SURVEY','EGG8395E','Ah Dee','Carry 2 tank',1724700283,'anonymous user',NULL,NULL,NULL,5),('3bf1074eb6b848ac9b972232c531342c','42ed36198211487f9526e2d9953d8717','RO24340001-0012',1724753812,'YET_TO_SURVEY','EGB8805V','AH DEE','Remarks for outgate',1724753812,'anonymous user',NULL,NULL,NULL,12),('484c2024d18e4f319588fef8629982e4','92f68b9594d247d8aebf1430194f0c96','RO24350001-0009',1724700287,'YET_TO_SURVEY','EGG8395E','Ah Dee','Carry 2 tank',1724700287,'anonymous user',NULL,NULL,NULL,9),('5834b0e9e1ac41c5b9829e66a6459f72','92f68b9594d247d8aebf1430194f0c96','RO24350001-0004',1724700264,'YET_TO_SURVEY','EGG8395E','Ah Dee','Carry 2 tank',1724700264,'anonymous user',NULL,NULL,NULL,4),('594394294057476ba748c26f3554ac3c','f3996dad18764c269a8a94301312b983','RO24370001-0001',1725993227,'YET_TO_SURVEY','EGC8849F','Ah Dee','Input by admin using system',1725993227,'anonymous user',NULL,NULL,NULL,1),('5e18b5d7b07149be833c0d948f93ac1b','92f68b9594d247d8aebf1430194f0c96','RO24350001-0006',1724700284,'YET_TO_SURVEY','EGG8395E','Ah Dee','Carry 2 tank',1724700284,'anonymous user',NULL,NULL,NULL,6),('6826875bd9374c9892dc723da44ea002','92f68b9594d247d8aebf1430194f0c96','RO24350001-0008',1724700286,'YET_TO_SURVEY','EGG8395E','Ah Dee','Carry 2 tank',1724700286,'anonymous user',NULL,NULL,NULL,8),('7b9196eab8654bbbbe6896d9db76b596','92f68b9594d247d8aebf1430194f0c96','RO24350001-0011',1724700292,'YET_TO_SURVEY','EGG8395E','Ah Dee','Carry 2 tank',1724700292,'anonymous user',NULL,NULL,NULL,11),('9bd193d955c145bd96b1694d398e3325','3161c629204645f9becc66a2dc0e7a90','RO24340002-0001',1724340106,'YET_TO_SURVEY','JKN3316','Yukoko','Romila',1724340106,'anonymous user',1725202112,'anonymous user',NULL,1),('c009bf9beaa24985bf9d9d232d40917a','f0de519d3c584dcb9c5a1c6fcdcc6875','RO24350001-0014',1725111509,'YET_TO_SURVEY','GLP8990','Yelo Nima','Hey so Hey town',1725111509,'anonymous user',1725111623,'anonymous user',NULL,14),('c0d0870bd39442c0860811631ccab5a4','42ed36198211487f9526e2d9953d8717','RO24340001-0013',1724753824,'YET_TO_SURVEY','EGB8805V','AH DEE','Remarks for outgate',1724753824,'anonymous user',NULL,NULL,NULL,13),('c4eca880cbe44437bc601aaebfe97d4c','92f68b9594d247d8aebf1430194f0c96','RO24350001-0007',1724700285,'YET_TO_SURVEY','EGG8395E','Ah Dee','Carry 2 tank',1724700285,'anonymous user',NULL,NULL,NULL,7);
/*!40000 ALTER TABLE `out_gate` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`idms_admin`@`%`*/ /*!50003 TRIGGER `out_gate_BEFORE_INSERT` BEFORE INSERT ON `out_gate` FOR EACH ROW BEGIN
  DECLARE max_number INT;
    DECLARE current_year CHAR(2);
    DECLARE current_week CHAR(2);
    DECLARE current_dt DATETIME;

    -- Convert epoch time to datetime
    SET current_dt = FROM_UNIXTIME(NEW.create_dt);

    -- Get the current year and week number
    SET current_year = DATE_FORMAT(current_dt, '%y');
    SET current_week = LPAD(WEEK(current_dt, 1), 2, '0'); -- ISO week

    -- Get the current maximum running number for the year and week
    SELECT COALESCE(MAX(running_number), 0) + 1 INTO max_number
    FROM out_gate
    WHERE YEAR(FROM_UNIXTIME(create_dt)) = YEAR(current_dt)
    AND WEEK(FROM_UNIXTIME(create_dt), 1) = WEEK(current_dt, 1);

    -- Set the running number
    SET NEW.running_number = max_number;

    -- Generate the EIR_NO
    SET NEW.eir_no = CONCAT(NEW.eir_no,'-',  LPAD(max_number, 4, '0'));
    set NEW.eir_status_cv='YET_TO_SURVEY';
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-24 21:53:24
