-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `in_gate_survey`
--

DROP TABLE IF EXISTS `in_gate_survey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `in_gate_survey` (
  `guid` varchar(36) NOT NULL,
  `in_gate_guid` varchar(36) DEFAULT NULL COMMENT 'get last cargo from here',
  `capacity` int DEFAULT NULL,
  `tare_weight` int DEFAULT NULL,
  `take_in_reference` varchar(15) DEFAULT NULL,
  `last_test_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = TEST_TYPE',
  `next_test_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = TEST_TYPE',
  `test_dt` bigint DEFAULT NULL,
  `test_class_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = TEST_CLASS',
  `dom_dt` bigint DEFAULT NULL,
  `inspection_dt` bigint DEFAULT NULL,
  `last_release_dt` bigint DEFAULT NULL,
  `manufacturer_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = MANUFACTURER',
  `cladding_cv` varchar(20) DEFAULT NULL,
  `max_weight_cv` varchar(20) DEFAULT NULL,
  `height_cv` varchar(20) DEFAULT NULL,
  `walkway_cv` varchar(20) DEFAULT NULL,
  `tank_comp_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = TANK_COMP_TYPE',
  `btm_dis_comp_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = DIS_COMP',
  `btm_dis_valve_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = DIS_VALVE',
  `btm_valve_brand_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = VALVE_BRAND',
  `btm_dis_valve_spec_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = DIS_VALVE_SPEC',
  `top_dis_comp_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = DIS_COMP',
  `top_dis_valve_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = DIS_VALVE',
  `top_valve_brand_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = VALVE_BRAND',
  `top_dis_valve_spec_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = DIS_VALVE_SPEC',
  `manlid_comp_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = DIS_COMP',
  `foot_valve_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = FOOT_VALVE',
  `thermometer` int DEFAULT NULL,
  `thermometer_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = THERMOMETER',
  `ladder` tinyint DEFAULT NULL,
  `data_csc_transportplate` tinyint DEFAULT NULL,
  `airline_valve_pcs` int DEFAULT NULL,
  `airline_valve_dim` float DEFAULT NULL,
  `airline_valve_cv` varchar(20) DEFAULT NULL,
  `airline_valve_conn_cv` varchar(20) DEFAULT NULL,
  `airline_valve_conn_spec_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = MANLID_COVER',
  `manlid_cover_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = MANLID_COVER',
  `manlid_cover_pcs` int DEFAULT NULL,
  `manlid_cover_pts` int DEFAULT NULL,
  `manlid_seal_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = MANLID_SEAL',
  `pv_type_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = PV_TYPE',
  `pv_spec_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = PV_SPEC',
  `pv_type_pcs` int DEFAULT NULL,
  `pv_spec_pcs` int DEFAULT NULL,
  `safety_handrail` tinyint DEFAULT NULL,
  `buffer_plate` int DEFAULT NULL,
  `residue` float DEFAULT NULL,
  `dipstick` tinyint DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `update_dt` bigint DEFAULT NULL,
  `update_by` varchar(45) DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  `top_coord` json DEFAULT NULL,
  `bottom_coord` json DEFAULT NULL,
  `front_coord` json DEFAULT NULL,
  `rear_coord` json DEFAULT NULL,
  `left_coord` json DEFAULT NULL,
  `right_coord` json DEFAULT NULL,
  `top_remarks` varchar(120) DEFAULT NULL,
  `bottom_remarks` varchar(120) DEFAULT NULL,
  `front_remarks` varchar(120) DEFAULT NULL,
  `rear_remarks` varchar(120) DEFAULT NULL,
  `left_remarks` varchar(120) DEFAULT NULL,
  `right_remarks` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `in_gate_survey`
--

LOCK TABLES `in_gate_survey` WRITE;
/*!40000 ALTER TABLE `in_gate_survey` DISABLE KEYS */;
INSERT INTO `in_gate_survey` VALUES ('27803428792c41c39a6004244463079c','43da9cdbf23b4a50a0ffdcdeb3d56415',10001,10002,NULL,'2.5_AIR','5_HYDRO',1472744981,'BV',1698854400,NULL,NULL,'JJAP','GPR','20000','8.5','U_WALKWAY','MULTICOMPARTMENT','BOX','BALL','FORTVALE','FLANGE','BOX','UNI','GUARD','OTHERS','BOX','PRL',10003,'BROKEN',1,NULL,10004,10005,'BUTTERFLY','BSP','PRL','SWIFT',10006,10007,'','RUPTURE_DISC','THREADED',10008,10009,1,10010,10011,NULL,NULL,1726218305,'anonymous user',NULL,NULL,NULL,'{\"dmgTop\": [], \"outerTop\": [], \"dmgBottom\": [], \"dmgMiddle\": [], \"outerLeft\": [], \"outerRight\": [], \"walkwayTop\": [{\"x\": 0, \"y\": 0}, {\"x\": 1, \"y\": 0}, {\"x\": 2, \"y\": 0}, {\"x\": 3, \"y\": 0}], \"outerBottom\": [], \"walkwayBottom\": [{\"x\": 0, \"y\": 0}, {\"x\": 1, \"y\": 0}, {\"x\": 2, \"y\": 0}, {\"x\": 3, \"y\": 0}], \"walkwayMiddle\": [{\"x\": 6, \"y\": 0}, {\"x\": 7, \"y\": 0}, {\"x\": 8, \"y\": 0}, {\"x\": 11, \"y\": 0}]}','[]','[]','[]','[{\"x\": 0, \"y\": 2}, {\"x\": 15, \"y\": 2}, {\"x\": 2, \"y\": 5}, {\"x\": 14, \"y\": 6}]','[]','This is top remarks lai de',NULL,NULL,NULL,NULL,NULL),('538da7e02f73452192212150a10bd8fa','8ad2451c15104039bc24aa35f2085640',1111,1000,NULL,'2.5_AIR','5_HYDRO',1588263701,'ABS',1723305600,NULL,NULL,'CIMC','ALUMINIUM_WHITE','26000','9.5','PARALLEL','NO_BAFFLE','COVER','UNI','PEROLO','FLANGE','BOX','BALL','PEROLO','FLANGE','COVER','FV',100,'CONTAMINATED',NULL,1,12,12,'BALL','FLANGED','SWIFT','FV',22,33,'','VALVE','THREADED',11,33,NULL,12,34,1,NULL,1725113661,'anonymous user',NULL,NULL,NULL,'{\"dmgTop\": [], \"outerTop\": [], \"dmgBottom\": [], \"dmgMiddle\": [], \"outerLeft\": [], \"outerRight\": [], \"walkwayTop\": [{\"x\": 0, \"y\": 0}, {\"x\": 1, \"y\": 0}, {\"x\": 2, \"y\": 0}, {\"x\": 3, \"y\": 0}], \"outerBottom\": [], \"walkwayBottom\": [{\"x\": 1, \"y\": 0}, {\"x\": 2, \"y\": 0}, {\"x\": 3, \"y\": 0}], \"walkwayMiddle\": [{\"x\": 6, \"y\": 0}, {\"x\": 7, \"y\": 0}, {\"x\": 8, \"y\": 0}, {\"x\": 11, \"y\": 0}]}','[]','[]','[]','[{\"x\": 0, \"y\": 1}, {\"x\": 1, \"y\": 2}, {\"x\": 2, \"y\": 2}, {\"x\": 3, \"y\": 2}, {\"x\": 4, \"y\": 2}, {\"x\": 5, \"y\": 2}]','[]',NULL,NULL,NULL,NULL,NULL,NULL),('7600ae371d8a4ea98cf4c911d9bee675','a80ee5f37881491e8ba6abbdd202405e',111,222,NULL,'5_HYDRO','2.5_AIR',1588339283,'LR',1368460800,NULL,NULL,'CXIC','GPR','26000','9.5','U_WALKWAY','BAFFLE','COVER','UNI','FORTVALE','OTHERS','BOX','BALL','PEROLO','OTHERS','BOX','FV',333,'CONTAMINATED',1,NULL,555,444,'BUTTERFLY','FLANGED','FV','PRL',666,777,'','RUPTURE_DISC','THREADED',888,999,1,1000,11000,NULL,NULL,NULL,NULL,1724073728,'anonymous user',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('7ebeaaed1c894bb386cee28c1f58b6cc','4ba02f58bdd34fdb9c46e32349851bf2',200,300,NULL,NULL,NULL,NULL,NULL,1723132800,NULL,NULL,'SINGAMAS','ALUMINIUM_WHITE','26000','9.5','L_WALKWAY','BAFFLE','COVER','OTHERS','GUARD','FLANGE','BOX','UNI','PELICAN','CLAMPS','COVER','PRL',2,'CONTAMINATED',NULL,1,2,20,'BALL','OTHERS','SWIFT','FV',2,3,'','VALVE','THREADED',3,2,1,313,131,1,'Other Comment for CLTU',1723135775,'anonymous user',1723132768,'anonymous user',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('7f4c01614437485f9552259cd386da28','acb729de5dd94490bdd92daad92c6dcf',1000,1001,NULL,'2.5_AIR','5_HYDRO',1630500697,'ABS',1709827200,NULL,NULL,'CXIC','GPR','30000','9.5','H_WALKWAY','BAFFLE','BOX','BALL','FORTVALE','FLANGE','BOX','BALL','PELICAN','OTHERS','BOX','OTHERS',1002,'BROKEN',NULL,NULL,1003,1004,'OTHERS','FLANGED','SWIFT','FV',1005,1006,'','VALVE','THREADED',1007,1008,1,1009,1010,0,NULL,1726319008,'anonymous user',NULL,NULL,NULL,'{\"dmg\": [{\"x\": 0, \"y\": 0}, {\"x\": 1, \"y\": 0}, {\"x\": 2, \"y\": 0}, {\"x\": 3, \"y\": 0}, {\"x\": 4, \"y\": 0}, {\"x\": 5, \"y\": 0}, {\"x\": 6, \"y\": 0}, {\"x\": 7, \"y\": 0}, {\"x\": 8, \"y\": 0}, {\"x\": 9, \"y\": 0}, {\"x\": 10, \"y\": 0}, {\"x\": 11, \"y\": 0}, {\"x\": 12, \"y\": 0}, {\"x\": 13, \"y\": 0}, {\"x\": 14, \"y\": 0}, {\"x\": 15, \"y\": 0}, {\"x\": 16, \"y\": 0}, {\"x\": 17, \"y\": 0}, {\"x\": 18, \"y\": 0}, {\"x\": 0, \"y\": 10}, {\"x\": 1, \"y\": 10}, {\"x\": 2, \"y\": 10}, {\"x\": 3, \"y\": 10}, {\"x\": 4, \"y\": 10}, {\"x\": 5, \"y\": 10}, {\"x\": 6, \"y\": 10}, {\"x\": 7, \"y\": 10}, {\"x\": 8, \"y\": 10}, {\"x\": 9, \"y\": 10}, {\"x\": 10, \"y\": 10}, {\"x\": 11, \"y\": 10}, {\"x\": 12, \"y\": 10}, {\"x\": 13, \"y\": 10}, {\"x\": 14, \"y\": 10}, {\"x\": 15, \"y\": 10}, {\"x\": 16, \"y\": 10}, {\"x\": 17, \"y\": 10}, {\"x\": 18, \"y\": 10}], \"walkwayTop\": [{\"x\": 0, \"y\": 0}, {\"x\": 1, \"y\": 0}, {\"x\": 2, \"y\": 0}, {\"x\": 3, \"y\": 0}], \"walkwayBottom\": [{\"x\": 0, \"y\": 0}, {\"x\": 1, \"y\": 0}, {\"x\": 2, \"y\": 0}, {\"x\": 3, \"y\": 0}], \"walkwayMiddle\": [{\"x\": 0, \"y\": 0}, {\"x\": 1, \"y\": 0}, {\"x\": 2, \"y\": 0}, {\"x\": 3, \"y\": 0}, {\"x\": 6, \"y\": 0}, {\"x\": 7, \"y\": 0}, {\"x\": 8, \"y\": 0}, {\"x\": 11, \"y\": 0}]}','[]','[]','[]','[]','[]',NULL,NULL,NULL,NULL,NULL,NULL),('8001c0fecaef4483954140f4c0bfc5bc','2a6f37148bad4b38a44881ae64429a04',1000,2111,NULL,'5_HYDRO','2.5_AIR',1588322627,'ABS',1723564800,NULL,NULL,'SINGAMAS','ALUMINIUM_WHITE','30000','8.5','U_WALKWAY','BAFFLE','BOX','BALL','FORTVALE','FLANGE','COVER','BALL','GUARD','FLANGE','COVER','OTHERS',200,'BROKEN',1,1,20,10,'OTHERS','FLANGED','SWIFT','PRL',24,57,'','VALVE','FLANGED',41,74,1,85,96,1,NULL,NULL,NULL,1723884284,'anonymous user',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8aa53f2aa6f34072989b6576575a0139','21fa757b1c944cdd93884f08252f4777',1100,2200,NULL,'2.5_AIR','5_HYDRO',1598966658,'DNV',1468425600,NULL,NULL,'WELFIT','GPR','34000','8.5','H_WALKWAY','MULTICOMPARTMENT','BOX','BALL','FORTVALE','OTHERS','BOX','UNI','FORTVALE','OTHERS','BOX','FV',3300,'CONTAMINATED',0,0,4400,5500,'BUTTERFLY','FLANGED','PRL','PRL',6600,7700,'','RUPTURE_DISC','FLANGED',9900,8800,NULL,1101,1102,NULL,'The comments',1724173698,'anonymous user',NULL,NULL,NULL,'[{\"x\": 0, \"y\": 6}, {\"x\": 8, \"y\": 6}]','[{\"x\": 0, \"y\": 0}, {\"x\": 8, \"y\": 0}, {\"x\": 4, \"y\": 3}, {\"x\": 0, \"y\": 6}, {\"x\": 8, \"y\": 6}]','[{\"x\": 0, \"y\": 0}, {\"x\": 0, \"y\": 6}]','[{\"x\": 0, \"y\": 0}, {\"x\": 8, \"y\": 0}]','[{\"x\": 0, \"y\": 0}, {\"x\": 0, \"y\": 6}]','[{\"x\": 8, \"y\": 0}, {\"x\": 8, \"y\": 6}]',NULL,NULL,NULL,NULL,NULL,NULL),('9b90e1a4363c439fbb0ad0adaf86596a','02e196935a0b486eb384076b43d21997',1001,1002,NULL,'2.5_AIR','5_HYDRO',1451632134,'DNV',1711987200,NULL,NULL,'CIMC','ALUMINIUM_WHITE','36000','8.5','8_WALKWAY','MULTICOMPARTMENT','COVER','BALL','PELICAN','FLANGE','BOX','BALL','PEROLO','FLANGE','COVER','FV',1003,'BROKEN',1,1,1004,1005,'BUTTERFLY','OTHERS','SWIFT','SWIFT',1006,1007,'','VALVE','THREADED',1008,1009,1,1010,1011,1,'No comment',NULL,NULL,1723964952,'anonymous user',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('b89c290a533549fea6f233975b538d57','91e2d6eefaf34a08b2a740a8de7eea82',31111,31112,NULL,'2.5_AIR','5_HYDRO',1622561741,'DNV',1726416000,NULL,NULL,'JJAP','GPR','26000','8.5','U_WALKWAY','BAFFLE','BOX','UNI','PELICAN','FLANGE','BOX','BALL','PELICAN','FLANGE','BOX','PRL',31113,'BROKEN',0,1,31114,31115,'BUTTERFLY','BSP','SWIFT','PRL',31116,31117,'','VALVE','THREADED',31118,31119,NULL,31120,31121,NULL,'Rereta',1726587897,'anonymous user',NULL,NULL,NULL,'{\"dmg\": [{\"x\": 16, \"y\": 0}, {\"x\": 17, \"y\": 0}, {\"x\": 18, \"y\": 0}, {\"x\": 16, \"y\": 1}, {\"x\": 17, \"y\": 1}, {\"x\": 18, \"y\": 1}, {\"x\": 16, \"y\": 2}, {\"x\": 17, \"y\": 2}, {\"x\": 18, \"y\": 2}], \"walkwayTop\": [{\"x\": 0, \"y\": 0}, {\"x\": 1, \"y\": 0}, {\"x\": 2, \"y\": 0}, {\"x\": 3, \"y\": 0}], \"walkwayBottom\": [{\"x\": 0, \"y\": 0}, {\"x\": 1, \"y\": 0}, {\"x\": 2, \"y\": 0}, {\"x\": 3, \"y\": 0}], \"walkwayMiddle\": [{\"x\": 0, \"y\": 0}, {\"x\": 1, \"y\": 0}, {\"x\": 2, \"y\": 0}, {\"x\": 3, \"y\": 0}, {\"x\": 11, \"y\": 0}]}','[]','[]','[]','[{\"x\": 0, \"y\": 8}, {\"x\": 1, \"y\": 8}, {\"x\": 2, \"y\": 8}, {\"x\": 0, \"y\": 9}, {\"x\": 1, \"y\": 9}, {\"x\": 2, \"y\": 9}, {\"x\": 0, \"y\": 10}, {\"x\": 1, \"y\": 10}, {\"x\": 2, \"y\": 10}]','[]',NULL,NULL,NULL,NULL,NULL,NULL),('c12ce22748ff4baeae5c2758e853b141','a759958a23c44a6d82e0f6431db376cb',200,300,NULL,'5_HYDRO','2.5_AIR',1583068743,'ABS',1670947200,NULL,NULL,'CIMC','ALUMINIUM_WHITE','30000','9.5','8_WALKWAY','BAFFLE','COVER','UNI','PELICAN','FLANGE','COVER','UNI','GUARD','OTHERS','BOX','OTHERS',400,'CONTAMINATED',0,1,600,700,'BALL','FLANGED','SWIFT','PRL',700,800,'','VALVE','FLANGED',1000,900,1,7000,8000,0,NULL,NULL,NULL,1724073607,'anonymous user',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d2331271865f4d1198d7f3214edff6e2','8ad2451c15104039bc24aa35f2085640',1000,1000,NULL,'2.5_AIR','5_HYDRO',1588263701,'ABS',1723305600,NULL,NULL,'CIMC','ALUMINIUM_WHITE','26000','9.5','PARALLEL','NO_BAFFLE','COVER','UNI','PEROLO','FLANGE','BOX','BALL','PEROLO','FLANGE','COVER','FV',100,'CONTAMINATED',NULL,1,12,12,'BALL','FLANGED','SWIFT','FV',22,33,'','VALVE','THREADED',11,33,NULL,12,34,1,NULL,1723818022,'anonymous user',1723308349,'anonymous user',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d574f0e9e0fa4bf598394f2ecb39ae5f','19a6fa05380546cb8a90da21e2804682',33,11,NULL,'2.5_AIR','5_HYDRO',1588344183,'BV',1105372800,NULL,NULL,'SINGAMAS','STAINLESS_STEEL','34000','8.5','H_WALKWAY','NO_BAFFLE','COVER','UNI','GUARD','OTHERS','BOX','BALL','GUARD','FLANGE','COVER','PRL',33,'SUSPECT_SPOIL',1,1,22,33,'BUTTERFLY','FLANGED','PRL','FV',44,55,'','VALVE','FLANGED',66,77,1,88,99,1,NULL,NULL,NULL,1723819852,'anonymous user',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('deb0ec95a1e84c0e80fc2654c6f4f48a','b3a32fa076034c1d831a195d3a82c83b',1000,2000,NULL,'2.5_AIR','5_HYDRO',1601559462,'BV',1696521600,NULL,NULL,'SINGAMAS','ALUMINIUM_WHITE','34000','8.5','U_WALKWAY','BAFFLE','COVER','UNI','FORTVALE','FLANGE','COVER','UNI','GUARD','FLANGE','BOX','FV',3000,'BROKEN',1,1,4000,5000,'OTHERS','OTHERS','SWIFT','SWIFT',6000,7000,'','RUPTURE_DISC','THREADED',8000,9000,1,10000,11000,1,'try other comments',1726231268,'anonymous user',NULL,NULL,NULL,'{\"dmgTop\": [{\"x\": 0, \"y\": 0}, {\"x\": 1, \"y\": 0}, {\"x\": 2, \"y\": 0}, {\"x\": 3, \"y\": 0}], \"outerTop\": [{\"x\": 18, \"y\": 0}], \"dmgBottom\": [{\"x\": 3, \"y\": 0}], \"dmgMiddle\": [{\"x\": 1, \"y\": 0}, {\"x\": 2, \"y\": 0}, {\"x\": 7, \"y\": 0}], \"outerLeft\": [], \"outerRight\": [{\"x\": 0, \"y\": 0}, {\"x\": 1, \"y\": 0}, {\"x\": 2, \"y\": 0}, {\"x\": 3, \"y\": 0}, {\"x\": 4, \"y\": 0}, {\"x\": 5, \"y\": 0}, {\"x\": 6, \"y\": 0}, {\"x\": 7, \"y\": 0}, {\"x\": 8, \"y\": 0}, {\"x\": 9, \"y\": 0}], \"walkwayTop\": [{\"x\": 0, \"y\": 0}, {\"x\": 1, \"y\": 0}, {\"x\": 2, \"y\": 0}, {\"x\": 3, \"y\": 0}], \"outerBottom\": [], \"walkwayBottom\": [{\"x\": 0, \"y\": 0}, {\"x\": 1, \"y\": 0}, {\"x\": 2, \"y\": 0}, {\"x\": 3, \"y\": 0}], \"walkwayMiddle\": [{\"x\": 0, \"y\": 0}, {\"x\": 1, \"y\": 0}, {\"x\": 2, \"y\": 0}, {\"x\": 3, \"y\": 0}, {\"x\": 6, \"y\": 0}, {\"x\": 7, \"y\": 0}, {\"x\": 8, \"y\": 0}, {\"x\": 11, \"y\": 0}]}','[{\"x\": 8, \"y\": 1}, {\"x\": 9, \"y\": 1}, {\"x\": 10, \"y\": 1}, {\"x\": 8, \"y\": 2}, {\"x\": 9, \"y\": 2}, {\"x\": 10, \"y\": 2}, {\"x\": 8, \"y\": 3}, {\"x\": 9, \"y\": 3}, {\"x\": 10, \"y\": 3}, {\"x\": 8, \"y\": 4}, {\"x\": 9, \"y\": 4}, {\"x\": 10, \"y\": 4}, {\"x\": 8, \"y\": 5}, {\"x\": 9, \"y\": 5}, {\"x\": 10, \"y\": 5}, {\"x\": 8, \"y\": 6}, {\"x\": 9, \"y\": 6}, {\"x\": 10, \"y\": 6}, {\"x\": 8, \"y\": 7}, {\"x\": 9, \"y\": 7}, {\"x\": 10, \"y\": 7}, {\"x\": 8, \"y\": 8}, {\"x\": 9, \"y\": 8}, {\"x\": 10, \"y\": 8}, {\"x\": 8, \"y\": 9}, {\"x\": 9, \"y\": 9}, {\"x\": 10, \"y\": 9}]','[{\"x\": 10, \"y\": 2}, {\"x\": 11, \"y\": 2}, {\"x\": 12, \"y\": 2}, {\"x\": 2, \"y\": 3}, {\"x\": 3, \"y\": 3}, {\"x\": 4, \"y\": 3}, {\"x\": 13, \"y\": 3}, {\"x\": 14, \"y\": 3}, {\"x\": 15, \"y\": 3}]','[{\"x\": 14, \"y\": 0}, {\"x\": 15, \"y\": 0}, {\"x\": 6, \"y\": 1}, {\"x\": 7, \"y\": 1}, {\"x\": 17, \"y\": 1}, {\"x\": 18, \"y\": 1}, {\"x\": 9, \"y\": 2}, {\"x\": 10, \"y\": 2}, {\"x\": 1, \"y\": 3}, {\"x\": 2, \"y\": 3}]','[]','[{\"x\": 2, \"y\": 1}, {\"x\": 3, \"y\": 1}, {\"x\": 4, \"y\": 1}, {\"x\": 5, \"y\": 1}, {\"x\": 6, \"y\": 1}, {\"x\": 7, \"y\": 1}, {\"x\": 2, \"y\": 2}, {\"x\": 3, \"y\": 2}, {\"x\": 4, \"y\": 2}, {\"x\": 5, \"y\": 2}, {\"x\": 6, \"y\": 2}, {\"x\": 7, \"y\": 2}, {\"x\": 12, \"y\": 6}, {\"x\": 13, \"y\": 6}, {\"x\": 14, \"y\": 6}, {\"x\": 15, \"y\": 6}, {\"x\": 16, \"y\": 6}, {\"x\": 17, \"y\": 6}, {\"x\": 12, \"y\": 7}, {\"x\": 13, \"y\": 7}, {\"x\": 14, \"y\": 7}, {\"x\": 15, \"y\": 7}, {\"x\": 16, \"y\": 7}, {\"x\": 17, \"y\": 7}]',NULL,NULL,NULL,NULL,'Bonus!!',NULL),('e56061c5af14412f81040dfc882a83e5','46b74f652b114cb99bee51ecd1656010',1001,1002,NULL,'2.5_AIR','5_HYDRO',1664600696,'DNV',1722441600,NULL,NULL,'CIMC','ALUMINIUM_WHITE','30000','8.5','U_WALKWAY','BAFFLE','COVER','UNI','PEROLO','FLANGE','BOX','UNI','PEROLO','FLANGE','BOX','FV',1003,'BROKEN',1,NULL,1004,1005,'BALL','BSP','SWIFT','SWIFT',1006,1007,'','VALVE','THREADED',1008,1009,1,1010,1011,0,NULL,NULL,NULL,1725858384,'anonymous user',NULL,'{\"dmgTop\": [], \"outerTop\": [], \"dmgBottom\": [], \"dmgMiddle\": [], \"outerLeft\": [], \"outerRight\": [], \"walkwayTop\": [{\"x\": 0, \"y\": 0}, {\"x\": 1, \"y\": 0}, {\"x\": 2, \"y\": 0}, {\"x\": 3, \"y\": 0}], \"outerBottom\": [], \"walkwayBottom\": [{\"x\": 0, \"y\": 0}, {\"x\": 1, \"y\": 0}, {\"x\": 2, \"y\": 0}, {\"x\": 3, \"y\": 0}], \"walkwayMiddle\": [{\"x\": 6, \"y\": 0}, {\"x\": 7, \"y\": 0}, {\"x\": 8, \"y\": 0}, {\"x\": 11, \"y\": 0}]}','[]','[]','[]','[{\"x\": 1, \"y\": 0}, {\"x\": 1, \"y\": 2}, {\"x\": 1, \"y\": 5}, {\"x\": 1, \"y\": 7}, {\"x\": 1, \"y\": 10}]','[]',NULL,NULL,NULL,NULL,NULL,NULL),('f0fe34bc2601435a8a0dd12663592161','0ee01378c4f74608810dd8bf6d49f723',100,200,NULL,'5_HYDRO','2.5_AIR',1580563061,'ABS',1696435200,NULL,NULL,'SINGAMAS','ALUMINIUM_WHITE','36000','8.5','H_WALKWAY','MULTICOMPARTMENT','BOX','UNI','FORTVALE','FLANGE','BOX','BALL','PEROLO','OTHERS','COVER','PRL',300,'SUSPECT_SPOIL',1,1,400,500,'BUTTERFLY','FLANGED','SWIFT','PRL',600,700,'','VALVE','THREADED',800,900,1,1000,1100,1,NULL,NULL,NULL,1724073523,'anonymous user',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `in_gate_survey` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-24 21:54:17
