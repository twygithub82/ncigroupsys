-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `template_est`
--

DROP TABLE IF EXISTS `template_est`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `template_est` (
  `guid` varchar(36) NOT NULL,
  `type_cv` varchar(20) NOT NULL COMMENT 'code_value_type = EST_TEMPLATE_TYPE',
  `labour_cost_discount` double NOT NULL DEFAULT '0',
  `material_cost_discount` double NOT NULL DEFAULT '0',
  `template_name` varchar(50) NOT NULL,
  `remarks` varchar(120) DEFAULT NULL,
  `update_dt` bigint DEFAULT NULL,
  `update_by` varchar(45) DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template_est`
--

LOCK TABLES `template_est` WRITE;
/*!40000 ALTER TABLE `template_est` DISABLE KEYS */;
INSERT INTO `template_est` VALUES ('006ccd75d66944f2a2d7e9eaff12558b','GENERAL',1,1,'Template 32',NULL,NULL,NULL,1726489429,'anonymous user',NULL),('0533eb0de7bf4245837b4105be92c6c2','EXCLUSIVE',0,0,'Guo',NULL,NULL,NULL,1726240181,'anonymous user',NULL),('1f08fafb5f7f4141ab05f30f61993262','EXCLUSIVE',0,0,'Temp 1233',NULL,1726994775,'anonymous user',1726232584,'anonymous user',NULL),('2a172bc7978243dbb8a306037bebe8a2','GENERAL',0,0,'temp 4344',NULL,NULL,NULL,1726581103,'anonymous user',NULL),('3ec3aa7a6e914af88f59727958880544','GENERAL',2,1,'General 1',NULL,1727185948,'anonymous user',1726983794,'anonymous user',NULL),('45f34e1336c448759e68f0285afbd17d','EXCLUSIVE',0,0,'test124',NULL,NULL,NULL,1726240321,'anonymous user',NULL),('5539cb2a9d4a4a5a8350f43447139174','EXCLUSIVE',1,2,'1232',NULL,1727183543,'anonymous user',1726214116,'anonymous user',NULL),('554afd6447a14208a5f5e31d6342a0f9','GENERAL',0,0,'temp 4521',NULL,NULL,NULL,1726755171,'anonymous user',NULL),('5f247f5450dd4b1f8dafed2bdf9ac2df','GENERAL',1,2,'Test template',NULL,1726994323,'anonymous user',1726972755,'anonymous user',NULL),('6110594a7aeb4f6084745fd747f947c7','EXCLUSIVE',1,1,'teyy',NULL,NULL,NULL,1726241322,'anonymous user',NULL),('62ebf588b5954cfb841aee798ac752ac','GENERAL',0,0,'Temp 789465',NULL,NULL,NULL,1726754958,'anonymous user',NULL),('62fdd6f10d0f42cf84c6b887239f052d','EXCLUSIVE',0,0,'TEMPLATE 789',NULL,NULL,NULL,1726233761,'anonymous user',NULL),('669a026c8b9c4054a05bb6b8c3a4a0f3','EXCLUSIVE',1,2,'Template 12034',NULL,NULL,NULL,1726579622,'anonymous user',NULL),('69b0bef94440454e817e1802d22a74fd','GENERAL',1,2,'testTemp',NULL,NULL,NULL,1726994137,'anonymous user',NULL),('879adfc7b17c4447bd5fca5b4b76a075','GENERAL',2,2,'abcd',NULL,1727185360,'anonymous user',1726666253,'anonymous user',NULL),('a82682b120de42bfbc7d876f68a91f6d','EXCLUSIVE',1,0,'Temp 123',NULL,1726994743,'anonymous user',1726232369,'anonymous user',NULL),('b56cf505bbdd4723800f1e09ca85042f','EXCLUSIVE',1,2,'abc',NULL,1727184202,'anonymous user',1725692053,'anonymous user',NULL),('bd4875cb99744a7a80fb09cdc3bd0d15','EXCLUSIVE',0,0,'test 1456',NULL,NULL,NULL,1726233958,'anonymous user',NULL),('fa34e7286efb45b48ceb5988febed12b','GENERAL',0,0,'Template 1231',NULL,NULL,NULL,1726233259,'anonymous user',NULL);
/*!40000 ALTER TABLE `template_est` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-24 21:53:10
