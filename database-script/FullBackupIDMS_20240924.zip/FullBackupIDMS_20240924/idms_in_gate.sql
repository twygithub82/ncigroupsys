-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `in_gate`
--

DROP TABLE IF EXISTS `in_gate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `in_gate` (
  `guid` varchar(36) NOT NULL,
  `so_tank_guid` varchar(36) DEFAULT NULL,
  `eir_no` varchar(36) DEFAULT NULL,
  `eir_dt` bigint DEFAULT NULL,
  `eir_status_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = EIR_STATUS',
  `vehicle_no` varchar(20) DEFAULT NULL,
  `driver_name` varchar(120) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `yard_cv` varchar(20) DEFAULT NULL,
  `lolo_cv` varchar(20) DEFAULT NULL,
  `preinspection_cv` varchar(20) DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `update_dt` bigint DEFAULT NULL,
  `update_by` varchar(45) DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  `running_number` int NOT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `in_gate`
--

LOCK TABLES `in_gate` WRITE;
/*!40000 ALTER TABLE `in_gate` DISABLE KEYS */;
INSERT INTO `in_gate` VALUES ('0203c480297c475b99d27b32d4613b96','459535932b8340b4a572d7aea58bdbad','SO24380001-0006',1726587055,'YET_TO_SURVEY','GFD1511','Todilo','Reeed','YARD_2','BOTH','Y',1726587055,'anonymous user',1726587156,'admin',1726587156,6),('021efacaeb974faf9165f13b63d40fd9','148e24c318e644a3aaf0afbb2133fbfe','SO24280008-0001',1723443435,'YET_TO_SURVEY','ECF8375F','Mutu',NULL,'YARD_1','LIFT_ON','N',1723443435,'anonymous user',1724371710,'admin',1724371710,1),('02e196935a0b486eb384076b43d21997','ba639716a2ca40dabf40352000cf5675','SO24320001-0006',1723964779,'PENDING','HTJ3113','Gravity',NULL,'YARD_2','BOTH','Y',1723964779,'anonymous user',1723964952,'anonymous user',NULL,6),('031c3a546170450d9dd282fbdc5d50df','459535932b8340b4a572d7aea58bdbad','SO24380001-0005',1726586946,'YET_TO_SURVEY','ASD6613','Gita','Raad','YARD_1','BOTH','Y',1726586946,'anonymous user',1726586973,'admin',1726586973,5),('0621ed2b89944afbbe80129b7c236099','e05e9a3b85a54fb49bbc84b30f1e8096','SO24280009-0004',1723738548,'YET_TO_SURVEY','HGT6711','Mojito',NULL,'YARD_1','BOTH','Y',1723738548,'anonymous user',NULL,NULL,NULL,4),('0ee01378c4f74608810dd8bf6d49f723','3161c629204645f9becc66a2dc0e7a90','SO24340001-0001',1724073167,'PENDING','GFD1333','Ah Li',NULL,'YARD_2','BOTH','N',1724073167,'anonymous user',1724073523,'anonymous user',NULL,1),('0f232c54aef342d69e2fd1031066bb3e','f07c888e57f94a439a40d9915cab60fb','SO24340004-0013',1724506980,'YET_TO_SURVEY','GBT3313','Mohehe Lilo',NULL,'YARD_2','BOTH','N',1724506980,'anonymous user',1724507423,'admin',1724507423,13),('17a10d1926a648838fd438fed52d1e57','f3996dad18764c269a8a94301312b983','SO24340003-0010',1724504843,'YET_TO_SURVEY','GTY4221','Mohaha Nili',NULL,'YARD_1','BOTH','Y',1724504843,'anonymous user',1724504949,'admin',1724504949,10),('19a6fa05380546cb8a90da21e2804682','ae633187c8254ddbb105bce4008c34b1','SO24280010-0007',1723272483,'PENDING','EGD3849E','Mutu',NULL,'YARD_1','LIFT_OFF','N',1723272483,'anonymous user',1723819852,'anonymous user',NULL,7),('21fa757b1c944cdd93884f08252f4777','df3edfaeaa0c475a889d5886240f5267','SO24340001-0004',1724073230,'PENDING','GFD1333','Ah Li','That comments','YARD_1','BOTH','N',1724073230,'anonymous user',1724173698,'anonymous user',NULL,4),('2212ca7e6c5341d3ac132362ba9200b1','b3b265e4189a458ba68aeee610752db7','SO24280006-0005',1723254075,'YET_TO_SURVEY','ADD8871','Johnson',NULL,'YARD_2','BOTH','Y',1723254075,'anonymous user',NULL,NULL,NULL,5),('2a6f37148bad4b38a44881ae64429a04','ddd2fae721bd4a559d18d6465de409f7','SO24280006-0001',1723130730,'PENDING','ECG1234E','Alan',NULL,'YARD_1','BOTH','N',1723130730,'anonymous user',1723884284,'anonymous user',NULL,1),('43da9cdbf23b4a50a0ffdcdeb3d56415','4bae13891a9648d7831d17b022b6fff1','SO24340002-0009',1724493261,'PENDING','EJK3857B','Alibaba',NULL,'YARD_1','BOTH','N',1724493261,'anonymous user',1726218305,'anonymous user',NULL,9),('46b74f652b114cb99bee51ecd1656010','3ec0a98ff67e48b8930e52ca8955ca8c','SO24370001-0001',1725858262,'PENDING','TKN9101','Jojo Lee','Just Enough','YARD_1','BOTH','Y',1725858262,'anonymous user',1725889949,'admin',1725889949,1),('49ab06f310904f768d8a11dbb1f0f115','f07c888e57f94a439a40d9915cab60fb','SO24340004-0015',1724578467,'YET_TO_SURVEY','ECH2859T','Ah Dee',NULL,'YARD_2','BOTH','Y',1724578467,'anonymous user',1724578493,'admin',1724578493,15),('4ba02f58bdd34fdb9c46e32349851bf2','9ddc9a9860b04d84aba1d49051ebb60f','SO24280002-0003',1723131490,'PENDING','JEP3555E','AH KAW','In Gate Remarks CLTU','YARD_1','BOTH','Y',1723131490,'anonymous user',1723135775,'anonymous user',NULL,3),('57efcb6fe0cf4ec38f0fcb1e13e8a0ae','0b5cb26a320f4998a75108a235698922','SO24280005-0005',1724372978,'YET_TO_SURVEY','ABC1234E','Ali',NULL,'YARD_1','BOTH','N',1724372978,'anonymous user',NULL,NULL,NULL,5),('58babe533d1143d9b71b8ff58c736f91','459535932b8340b4a572d7aea58bdbad','SO24380001-0004',1726586841,'YET_TO_SURVEY','GLL3136','Roli','Gaha','YARD_1','BOTH','N',1726586841,'anonymous user',1726586874,'admin',1726586874,4),('59edd9a98ce543e5a54aba8ff51207c9','376a042f8d6345b5bee6679642953e9f','SO24280007-0002',1723131356,'YET_TO_SURVEY','ERF3844E','Ali',NULL,'YARD_2','BOTH','N',1723131356,'anonymous user',NULL,NULL,NULL,2),('6965f62f2f624635bc6f33b884718251','e05e9a3b85a54fb49bbc84b30f1e8096','SO24280009-0003',1723738286,'YET_TO_SURVEY','HGT6711','Mojito',NULL,'YARD_1','BOTH','Y',1723738286,'anonymous user',NULL,NULL,1723738286,3),('6f8a5291052d43688d356c02de7a8dae','fada38916c82458c96fd9ba238d5ce48','SO24340002-0006',1724486424,'YET_TO_SURVEY','EDT9385T','Alan',NULL,'YARD_1','BOTH','Y',1724486424,'anonymous user',1724486514,'admin',NULL,6),('707524a6535b456196c5f689027f535f','57a6e55318ea48ccbc955487527e5857','SO24280010-0007',1724487125,'YET_TO_SURVEY','ERS3456T','Mutu',NULL,'YARD_1','BOTH','N',1724487125,'anonymous user',1724487303,'admin',1724487303,7),('7950c12b4fd9487f9b6f63455ed5cdc7','f07c888e57f94a439a40d9915cab60fb','SO24340004-0014',1724578407,'YET_TO_SURVEY','EGH3857T','Ah Dee',NULL,'YARD_1','BOTH','N',1724578407,'anonymous user',1724578427,'admin',1724578427,14),('85977293f62c45e6a901871d38ad7517','f3996dad18764c269a8a94301312b983','SO24340003-0011',1724505134,'YET_TO_SURVEY','JHP8992','Mohaha Nilai',NULL,'YARD_1','BOTH','Y',1724505134,'anonymous user',1724505371,'admin',1724505371,11),('8ad2451c15104039bc24aa35f2085640','92f68b9594d247d8aebf1430194f0c96','SO24320003-0008',1723304550,'PENDING','EKL2344J','Ah Zai',NULL,'YARD_1','BOTH','Y',1723304550,'anonymous user',1725113661,'anonymous user',NULL,8),('91e2d6eefaf34a08b2a740a8de7eea82','459535932b8340b4a572d7aea58bdbad','SO24380001-0007',1726587230,'PENDING','HKK3900','Hirodi','Rett','YARD_1','BOTH','Y',1726587230,'anonymous user',1726587897,'anonymous user',NULL,7),('a759958a23c44a6d82e0f6431db376cb','5b545dad7bd04ec58c602077cc3f2004','SO24340001-0002',1724073207,'PENDING','GFD1333','Ah Li',NULL,'YARD_2','BOTH','N',1724073207,'anonymous user',1724073607,'anonymous user',NULL,2),('a80ee5f37881491e8ba6abbdd202405e','c9afa144ffb64bef94bdb923fdf97497','SO24340001-0003',1724073219,'PENDING','GFD1333','Ah Li',NULL,'YARD_2','BOTH','N',1724073219,'anonymous user',1724073728,'anonymous user',NULL,3),('acb729de5dd94490bdd92daad92c6dcf','42de9a3d91774aa18da69d6c6594e900','SO24320002-0008',1724487790,'PENDING','ESS3456G','Ali',NULL,'YARD_2','BOTH','Y',1724487790,'anonymous user',1726319008,'anonymous user',NULL,8),('b2bb0675b42d404ab69f0be1498384bf','3ec0a98ff67e48b8930e52ca8955ca8c','SO24370001-0001',1726503214,'YET_TO_SURVEY','HGJ3313','Drovindar',NULL,'YARD_1','BOTH','Y',1726503214,'anonymous user',NULL,NULL,NULL,1),('b3a32fa076034c1d831a195d3a82c83b','f3996dad18764c269a8a94301312b983','SO24340003-0012',1724505528,'PENDING','JUY8774','Mohaha Nilai','try to update in gate remarks here','YARD_1','BOTH','Y',1724505528,'anonymous user',1726231268,'anonymous user',NULL,12),('b4d757670aa84b4786ba367c8915116f','f0de519d3c584dcb9c5a1c6fcdcc6875','SO24320003-0009',1723307400,'YET_TO_SURVEY','EJJ9948N','Ah Kao',NULL,'YARD_2','BOTH','Y',1723307400,'anonymous user',NULL,NULL,NULL,9),('c104c3e9c39e4b1dbe19fa22c98aface','459535932b8340b4a572d7aea58bdbad','SO24380001-0002',1726581711,'YET_TO_SURVEY','VJH7813','Ramsoh','Rerem','YARD_1','BOTH','Y',1726581711,'anonymous user',1726586427,'anonymous user',1726585631,2),('c70e26ccf196458899fd9530eb37c7a3','42ed36198211487f9526e2d9953d8717','SO24320003-0002',1723450297,'YET_TO_SURVEY','EGB1234E','Ah Kao',NULL,'YARD_1','LIFT_ON','Y',1723450297,'anonymous user',NULL,NULL,NULL,2),('df1bc70e6f5f474a803c276cc90c13b2','499c6ea499dc4ef7ac57e69273f6189b','SO24280010-0006',1723254314,'YET_TO_SURVEY','ETT3888E','Ah Mao',NULL,'YARD_2','LIFT_OFF','Y',1723254314,'anonymous user',1723254918,'admin',1723254918,6),('f279a7d3b9cd47498472a84447f24e8f','459535932b8340b4a572d7aea58bdbad','SO24380001-0003',1726586654,'YET_TO_SURVEY','GHJ3131','ReongHi','Reade','YARD_2','BOTH','Y',1726586654,'anonymous user',1726586795,'admin',1726586795,3),('f3e88752f9614a5d9686bf849a8cbdbc','a8aac7c189894de0a3f57f1f120dcb26','SO24280007-0004',1723254039,'YET_TO_SURVEY','BGB7651','Donny',NULL,'YARD_1','BOTH','N',1723254039,'anonymous user',NULL,NULL,NULL,4);
/*!40000 ALTER TABLE `in_gate` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`idms_admin`@`%`*/ /*!50003 TRIGGER `trg_before_insert_in_gate` BEFORE INSERT ON `in_gate` FOR EACH ROW BEGIN
    DECLARE max_number INT;
    DECLARE current_year CHAR(2);
    DECLARE current_week CHAR(2);
    DECLARE current_dt DATETIME;

    -- Convert epoch time to datetime
    SET current_dt = FROM_UNIXTIME(NEW.create_dt);

    -- Get the current year and week number
    SET current_year = DATE_FORMAT(current_dt, '%y');
    SET current_week = LPAD(WEEK(current_dt, 1), 2, '0'); -- ISO week

    -- Get the current maximum running number for the year and week
    SELECT COALESCE(MAX(running_number), 0) + 1 INTO max_number
    FROM in_gate
    WHERE YEAR(FROM_UNIXTIME(create_dt)) = YEAR(current_dt)
    AND WEEK(FROM_UNIXTIME(create_dt), 1) = WEEK(current_dt, 1);

    -- Set the running number
    SET NEW.running_number = max_number;

    -- Generate the SO_NO
    SET NEW.eir_no = CONCAT(NEW.eir_no,'-',  LPAD(max_number, 4, '0'));
    set NEW.eir_status_cv='YET_TO_SURVEY';
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-24 21:54:07
