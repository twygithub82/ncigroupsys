-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `package_labour`
--

DROP TABLE IF EXISTS `package_labour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `package_labour` (
  `guid` varchar(36) NOT NULL,
  `tariff_labour_guid` varchar(36) DEFAULT NULL,
  `customer_company_guid` varchar(36) DEFAULT NULL,
  `cost` double DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `update_dt` bigint DEFAULT NULL,
  `update_by` varchar(45) DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package_labour`
--

LOCK TABLES `package_labour` WRITE;
/*!40000 ALTER TABLE `package_labour` DISABLE KEYS */;
INSERT INTO `package_labour` VALUES ('0ab85188ae7a4b9fbbf550beb7b2dac2','da5e23856a464f8eb09b7d87e2076208','6d8fc2522e5011ef91a300ff079339a5',20,'Labour Rate per Hour',NULL,NULL,1724571329,'anonymous user',NULL),('21ca6c875e2b44a3a32ca28d8aba9c19','da5e23856a464f8eb09b7d87e2076208','5d8fa4f02e5011ef91a300ff079339a5',20,'Labour Rate per Hour',NULL,NULL,1724571329,'anonymous user',NULL),('2890526bceb14828b7cd8a692730d692','da5e23856a464f8eb09b7d87e2076208','6d8fbe322e5011ef91a300ff079339a5',45,'Labour Rate per Hour',1726486970,'anonymous user',1724571329,'anonymous user',NULL),('2d71061ce6e146c29bec0ae2618444ec','da5e23856a464f8eb09b7d87e2076208','6d8fbc0e2e5011ef91a300ff079339a5',20,'Labour Rate per Hour',NULL,NULL,1724571402,'anonymous user',NULL),('42284aa1affa4a3ab31663fe3a429998','da5e23856a464f8eb09b7d87e2076208','5d8faa9d2e5011ef91a300ff079339a5',20,'Labour Rate per Hour',NULL,NULL,1724571329,'anonymous user',NULL),('5366d0c92ea34156a1c543ea381d1af6','da5e23856a464f8eb09b7d87e2076208','6d8fc6722e5011ef91a300ff079339a5',45,'test1',1726486970,'anonymous user',1724571329,'anonymous user',NULL),('6cca7bcde7e744078e8564c09f0c58d9','da5e23856a464f8eb09b7d87e2076208','6d8fc0422e5011ef91a300ff079339a5',20,'Labour Rate per Hour',NULL,NULL,1724571329,'anonymous user',NULL),('81261159d9d24304be566f4d69e1a1a9','da5e23856a464f8eb09b7d87e2076208','6d8fb9de2e5011ef91a300ff079339a5',20,'Labour Rate per Hour',NULL,NULL,1724571329,'anonymous user',NULL),('8c3705c3a22d4f5f8743d86d497b39b2','da5e23856a464f8eb09b7d87e2076208','6d8fc8822e5011ef91a300ff079339a5',20,'Labour Rate per Hour',NULL,NULL,1724571329,'anonymous user',NULL),('90b975621e0a4509b936ee23976a3cff','da5e23856a464f8eb09b7d87e2076208','6d8fca922e5011ef91a300ff079339a5',20,'Labour Rate per Hour',NULL,NULL,1724571402,'anonymous user',NULL),('9ad30a3b16414cc499759067103cfaa4','da5e23856a464f8eb09b7d87e2076208','5d8f899e2e5011ef91a300ff079339a5',20,'Labour Rate per Hour',NULL,NULL,1724571402,'anonymous user',NULL),('a7d5252e2f914a8f802911738145d01e','da5e23856a464f8eb09b7d87e2076208','6d8fc4622e5011ef91a300ff079339a5',45,'test1',1726486970,'anonymous user',1724571329,'anonymous user',NULL),('b31b70ce0ba146bf9969c6fd0e597246','da5e23856a464f8eb09b7d87e2076208','6d8fccb22e5011ef91a300ff079339a5',20,'Labour Rate per Hour',NULL,NULL,1724571329,'anonymous user',NULL),('b7aed7e3e1dc4ca2ab26bd31a10fb36e','da5e23856a464f8eb09b7d87e2076208','5d8fa01e2e5011ef91a300ff079339a5',20,'Labour Rate per Hour',NULL,NULL,1724571329,'anonymous user',NULL),('d745e8ec16a54d2f8bab9584672057d1','da5e23856a464f8eb09b7d87e2076208','5d8fa7822e5011ef91a300ff079339a5',20,'Labour Rate per Hour',NULL,NULL,1724571329,'anonymous user',NULL);
/*!40000 ALTER TABLE `package_labour` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-24 21:54:03
