-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `template_est_part`
--

DROP TABLE IF EXISTS `template_est_part`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `template_est_part` (
  `guid` varchar(36) NOT NULL,
  `tariff_repair_guid` varchar(36) NOT NULL,
  `template_est_guid` varchar(36) NOT NULL,
  `description` varchar(150) DEFAULT NULL,
  `location_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = PART_LOCATION',
  `remarks` varchar(150) DEFAULT NULL,
  `quantity` int NOT NULL DEFAULT '0',
  `hour` double NOT NULL DEFAULT '0',
  `update_by` varchar(45) DEFAULT NULL,
  `update_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template_est_part`
--

LOCK TABLES `template_est_part` WRITE;
/*!40000 ALTER TABLE `template_est_part` DISABLE KEYS */;
INSERT INTO `template_est_part` VALUES ('0009ed1ecc0b4c12aff723991feca397','1','69b0bef94440454e817e1802d22a74fd','Front test456 5','FRONT',NULL,1,2,NULL,NULL,'anonymous user',1726994137,NULL),('0379c63a6a2242bcbac9eb3597c4c00e','2','b56cf505bbdd4723800f1e09ca85042f','test 123 Front','FRONT',NULL,1,2,NULL,NULL,'anonymous user',1726758357,NULL),('0887967b8ad54e45aa3ea0fd0103c4e1','3','bd4875cb99744a7a80fb09cdc3bd0d15','CERTIFICATE CLEANING Rear','REAR',NULL,2,3,NULL,NULL,'anonymous user',1726233958,NULL),('08ce8d63a1d6433b9afef90c0ba0b5e4','4','6110594a7aeb4f6084745fd747f947c7','CERTIFICATE CLEANING Front','FRONT',NULL,1,1,NULL,NULL,'anonymous user',1726241322,NULL),('0b44c56e69814d73abca63125bd49e46','5','45f34e1336c448759e68f0285afbd17d','test 123 Front','FRONT',NULL,2,1,NULL,NULL,'anonymous user',1726240321,NULL),('28f0ec10557348ac839dbba4efe6d545','6','b56cf505bbdd4723800f1e09ca85042f','Front Insert mildsteel C-Channel 1 15','FRONT',NULL,1,0,NULL,NULL,'anonymous user',1726993858,NULL),('290781a94a7647ada4a2e6dd4275103c','7','5539cb2a9d4a4a5a8350f43447139174','Part 2 Front','FRONT',NULL,1,0,'anonymous user',1726903107,'anonymous user',1726903066,NULL),('4a3f38a5d5a840698f8a38e500bdac45','8','b56cf505bbdd4723800f1e09ca85042f','Rear test456 5','REAR',NULL,1,2,NULL,NULL,'anonymous user',1726993858,NULL),('4cab8df547214448a15c90fd2e9c5fa4','9','554afd6447a14208a5f5e31d6342a0f9','test Front','FRONT',NULL,1,2,NULL,NULL,'anonymous user',1726755171,NULL),('4d1607d6f65c4464943e345c22090946','10','1f08fafb5f7f4141ab05f30f61993262','Front Insert mildsteel C-Channel 1 16','FRONT',NULL,1,2,NULL,NULL,'anonymous user',1726994775,NULL),('50b6b4afbd294be488d18441e26e88a8','11','5f247f5450dd4b1f8dafed2bdf9ac2df','CERTIFICATE CLEANING Top','TOP',NULL,4,1,NULL,NULL,'anonymous user',1726972755,NULL),('55b152270e54468690b537bc2cf4204c','12','1f08fafb5f7f4141ab05f30f61993262','test456 Front','FRONT',NULL,2,3,NULL,NULL,'anonymous user',1726232584,NULL),('602229c1774c4cf895aec5bdcae366d7','13','3ec3aa7a6e914af88f59727958880544','CERTIFICATE CLEANING Rear','REAR',NULL,1,1,NULL,NULL,'anonymous user',1726983794,NULL),('60be90de83724eb7b6c92179e81a48f4','14','0533eb0de7bf4245837b4105be92c6c2','test456 Rear','REAR',NULL,2,0,NULL,NULL,'anonymous user',1726240181,NULL),('75cdc17e000a425ab4edda50f5b7fe5d','6c99bb9e7a0b11ef8d4b6045bd5acb12','3ec3aa7a6e914af88f59727958880544','Front Drain hose clip Renew null','FRONT',NULL,1,-1,NULL,NULL,'anonymous user',1727185397,NULL),('77f5a7b0b18a4839a024e80ac0e8b1c6','6c9aa1667a0b11ef8d4b6045bd5acb12','5539cb2a9d4a4a5a8350f43447139174','Front Cowl coupling cap SS null','FRONT',NULL,1,1,NULL,NULL,'anonymous user',1727183536,NULL),('8006b7e6838c4fa489043f1070325912','15','669a026c8b9c4054a05bb6b8c3a4a0f3','Insert mildsteel C-Channel 1 Front','FRONT',NULL,1,2,NULL,NULL,'anonymous user',1726579622,NULL),('80ee261fd67a471ab409f2e3be91fec7','16','669a026c8b9c4054a05bb6b8c3a4a0f3','test 123 Front','FRONT',NULL,1,2,NULL,NULL,'anonymous user',1726579622,NULL),('88e87d5ce2bf4467b1de7cc97f6e9f97','17','b56cf505bbdd4723800f1e09ca85042f','Insert mildsteel C-Channel 1 Front','FRONT',NULL,1,1,NULL,NULL,'anonymous user',1726758425,NULL),('8a341ecac53b475492054094d9376aad','18','5539cb2a9d4a4a5a8350f43447139174','Insert mildsteel C-Channel 1 Front','FRONT',NULL,0,1,'anonymous user',1727094810,'anonymous user',1726903169,1727094810),('90350e4ea0ad4f839a1b62330947848b','19','2a172bc7978243dbb8a306037bebe8a2','Part 2 Rear','REAR',NULL,1,2,NULL,NULL,'anonymous user',1726581103,NULL),('9af389f2ebea41ca8614685763c7327a','20','a82682b120de42bfbc7d876f68a91f6d','Front test456 5','FRONT',NULL,1,1,NULL,NULL,'anonymous user',1726994743,NULL),('9cc831d95d924a6ba6b701e0bbfe6120','6c9969827a0b11ef8d4b6045bd5acb12','5539cb2a9d4a4a5a8350f43447139174','Front Neckring swingbolt bracket null','FRONT',NULL,1,0,'anonymous user',1727183543,'anonymous user',1727183536,1727183543),('9e5dedb54a744627af0c4dbfb06e26d0','21','879adfc7b17c4447bd5fca5b4b76a075','Part 2 Front','FRONT',NULL,1,0,NULL,NULL,'anonymous user',1726666253,NULL),('a0fda7a8f7ec4cff9d5a8814de8d6911','22','62ebf588b5954cfb841aee798ac752ac','test456 Front','FRONT',NULL,1,0,NULL,NULL,'anonymous user',1726754958,NULL),('aa09f294528c4412b7e63ec06963dbc6','23','b56cf505bbdd4723800f1e09ca85042f','new description','TOP','this is top',1,1.5,'anonymous user',1726993895,'anonymous user',1725692053,NULL),('b90f1b153d1b428796fb22625ef298b7','24','006ccd75d66944f2a2d7e9eaff12558b','CERTIFICATE CLEANING Front','FRONT',NULL,2,1,NULL,NULL,'anonymous user',1726489429,NULL),('bf4c9eb1bdd042eb9d48f4e7618a659a','6c9969827a0b11ef8d4b6045bd5acb12','b56cf505bbdd4723800f1e09ca85042f','Front Neckring swingbolt bracket null','FRONT',NULL,1,0,NULL,NULL,'anonymous user',1727184202,NULL),('bf6a373d13994e6f8878a3352beeb9ba','25','5539cb2a9d4a4a5a8350f43447139174','test456 Front','FRONT',NULL,2,2,NULL,NULL,'anonymous user',1726214116,NULL),('d453e8c530744063b4c7c65393b54825','26','a82682b120de42bfbc7d876f68a91f6d','test456 Front','FRONT',NULL,2,3,NULL,NULL,'anonymous user',1726232369,NULL),('f0e42cdaf53f4150a13f86e11af93546','27','62fdd6f10d0f42cf84c6b887239f052d','test456 Front','FRONT',NULL,2,0,NULL,NULL,'anonymous user',1726233761,NULL),('f744b7d0bebf4bb8a510ea77acfacd69','28','fa34e7286efb45b48ceb5988febed12b','test Front','FRONT',NULL,2,1,NULL,NULL,'anonymous user',1726233259,NULL),('f9ebcde213a2403e865f092bbd779fa2','6c9aa1667a0b11ef8d4b6045bd5acb12','879adfc7b17c4447bd5fca5b4b76a075','Front Cowl coupling cap SS null','FRONT',NULL,1,2,NULL,NULL,'anonymous user',1727185353,NULL);
/*!40000 ALTER TABLE `template_est_part` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-24 21:53:02
