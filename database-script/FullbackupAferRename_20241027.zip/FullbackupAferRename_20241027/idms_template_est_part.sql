-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `template_est_part`
--

DROP TABLE IF EXISTS `template_est_part`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `template_est_part` (
  `guid` varchar(36) NOT NULL,
  `tariff_repair_guid` varchar(36) NOT NULL,
  `template_est_guid` varchar(36) NOT NULL,
  `description` varchar(150) DEFAULT NULL,
  `location_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = PART_LOCATION',
  `comment` varchar(120) DEFAULT NULL,
  `remarks` varchar(150) DEFAULT NULL,
  `quantity` int NOT NULL DEFAULT '0',
  `hour` double NOT NULL DEFAULT '0',
  `update_by` varchar(45) DEFAULT NULL,
  `update_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template_est_part`
--

LOCK TABLES `template_est_part` WRITE;
/*!40000 ALTER TABLE `template_est_part` DISABLE KEYS */;
INSERT INTO `template_est_part` VALUES ('039bcee56480470088d508c431b9fdc6','6c73e5fb7a0b11ef8d4b6045bd5acb12','fe0a85c9c501446bab9694bcbc7af906','Front  - Insert mildsteel Hollow 105cm','FRONT',NULL,NULL,1,1,'anonymous user',1728715694,'anonymous user',1728697325,NULL),('1183250dc2964fdfa60f634e59b2668e','6c78bb0d7a0b11ef8d4b6045bd5acb12','fe0a85c9c501446bab9694bcbc7af906','Top comment456 - 2.5yr Airtest - Labour only (IMO1 / IMO2)  remarks','TOP','comment456','remarks',2,0,'anonymous user',1727793334,'anonymous user',1727791411,1727793334),('13b42be50ff642a6a03b8fe7412e2ca5','6c8702657a0b11ef8d4b6045bd5acb12','1','Front test - Section Aluminum walkway 60cm (Mild)','FRONT','test','(Mild)',1,0,'anonymous user',1728197716,'anonymous user',1728197683,1728197716),('1edf0351ae2e45aba818335aada2adb5','6c7416c07a0b11ef8d4b6045bd5acb12','1','Front 10% - To polish','FRONT',NULL,NULL,1,0,'anonymous user',1727965717,'anonymous user',1727461585,1727965717),('24fc53345ce8414b9e2b903ede4891f7','6c73b8067a0b11ef8d4b6045bd5acb12','66400170beb14f2cb543e9e510d07c5e','Front Insert mildsteel Hollow 60cm (Custom Size 59CM)','FRONT',NULL,'(Custom Size 59CM)',1,0,NULL,NULL,'anonymous user',1727632652,NULL),('33a854ec47af4f298c1753465533e603','6c7416c07a0b11ef8d4b6045bd5acb12','1','Front test - 10% - To polish  test','FRONT','test','test',1,0,NULL,NULL,'anonymous user',1727965717,NULL),('354287ea8c444545b57db2cd8b68cd81','6c996b467a0b11ef8d4b6045bd5acb12','1','Swingbolt assembly (Baby tank)',NULL,NULL,NULL,1,2,'anonymous user',1727604406,'anonymous user',1727512996,NULL),('35e02a91f0c14db79737820f992bff6d','6c87012c7a0b11ef8d4b6045bd5acb12','1','Front Section Aluminum walkway 30 (Mild)','FRONT',NULL,'(Mild)',1,0,'anonymous user',1728197683,'anonymous user',1727461585,1728197683),('3a822e8ffe3c475bb49de779f3f9a70f','6c87012c7a0b11ef8d4b6045bd5acb12','d9e623f8fedf48b597d839892fcc61a7','Section Aluminum walkway 30',NULL,NULL,NULL,1,0,NULL,NULL,'anonymous user',1727510102,NULL),('40e89fb3cb324d5aa92628f2a2506854','6c9894077a0b11ef8d4b6045bd5acb12','d9e623f8fedf48b597d839892fcc61a7','Interior cleaning (IMO5) null',NULL,NULL,'',1,0,NULL,NULL,'anonymous user',1727510102,NULL),('59c3f6cb38144c81807ae43bb7534a61','6c786bee7a0b11ef8d4b6045bd5acb12','1','Front Data plate rusted to buff off  (still readable)','FRONT',NULL,'(still readable)',1,0,'anonymous user',1727604406,'anonymous user',1727461585,NULL),('5a8b0ab0722348deb0bb15b7ecf25677','6c78bb0d7a0b11ef8d4b6045bd5acb12','fe0a85c9c501446bab9694bcbc7af906','Front comments - 2.5yr Airtest - Labour only (IMO1 / IMO2)  remarks',NULL,NULL,NULL,1,0,'anonymous user',1727791411,'anonymous user',1727511050,1727791411),('746d7208c87a4679891ce5bea650721c','6c9969827a0b11ef8d4b6045bd5acb12','d9e623f8fedf48b597d839892fcc61a7','Neckring swingbolt bracket null',NULL,NULL,NULL,1,0,NULL,NULL,'anonymous user',1727510102,NULL),('7d11f55238f7476c9222ce503af4a43f','6c7756487a0b11ef8d4b6045bd5acb12','d9e623f8fedf48b597d839892fcc61a7','CSC plate null',NULL,NULL,NULL,1,0,NULL,NULL,'anonymous user',1727510102,NULL),('7d2050b1f620400f83304cf6ca985ebd','6c74cb017a0b11ef8d4b6045bd5acb12','854a708cbaf14b12b5ffb32dd47ad8d9','Front test - Renew thermowell  test','FRONT',NULL,'test',1,0,NULL,NULL,'anonymous user',1727965922,NULL),('80bf821850a340e4a3a3f1619c703ba1','6c86fc3c7a0b11ef8d4b6045bd5acb12','1','Chemical wash null',NULL,NULL,NULL,1,0,'anonymous user',1727512835,'anonymous user',1727512741,1727512835),('a9b49eef7c9946a089029a783286c485','6c7ab84f7a0b11ef8d4b6045bd5acb12','1','Front Exterior wash-cold water  (Cladding dirty & glue stain)','FRONT',NULL,'(Cladding dirty & glue stain)',1,0,'anonymous user',1727604406,'anonymous user',1727461585,NULL),('b1dc8aa3c5cb4281a06fad9ba0ab19d7','6c741acc7a0b11ef8d4b6045bd5acb12','1','Rear 10% grind & polish - Smooth surface null (non-transferable)','REAR',NULL,'(non-transferable)',1,0,'anonymous user',1727965742,'anonymous user',1727461585,1727965742),('ba502a30fd244dd483796933584d175e','6c9970fb7a0b11ef8d4b6045bd5acb12','fe0a85c9c501446bab9694bcbc7af906','Left cmt - Swingbolt assembly grub screw  rmk','LEFT','cmt','rmk',0,0,NULL,NULL,'anonymous user',1727793399,NULL),('c6e88a2439514698834ff2dc9c5e8fe9','6c996f067a0b11ef8d4b6045bd5acb12','854a708cbaf14b12b5ffb32dd47ad8d9','undefined - Swingbolt assembly 19mm  test',NULL,NULL,'test',1,0,NULL,NULL,'anonymous user',1727965922,NULL),('c9d8c16c65a84805940af5f6eede2ac2','6c9970fb7a0b11ef8d4b6045bd5acb12','1','Front yes - Swingbolt assembly grub screw  Top','FRONT','yes','Top',1,0,NULL,NULL,'anonymous user',1727966234,NULL),('cdda153d3c0d4114821320fc5ec81e0a','6c73b8067a0b11ef8d4b6045bd5acb12','d9e623f8fedf48b597d839892fcc61a7','Rear Insert mildsteel Hollow 60 (Custom Length 58CM)','REAR',NULL,'(Custom Length 58CM)',1,2,'anonymous user',1727631882,'anonymous user',1727518976,1727631882),('dd9cc4d0c9cb4736bffb1ca4c62f62de','6c864d607a0b11ef8d4b6045bd5acb12','1','Front Section mildsteel pipe 180 (All Frame)','FRONT',NULL,'(All Frame)',1,0,NULL,NULL,'anonymous user',1727461585,NULL),('e1042b4001f84596a2e9b308e3ed2a16','6c73b8067a0b11ef8d4b6045bd5acb12','d9e623f8fedf48b597d839892fcc61a7','Insert mildsteel Hollow 60cm (Custom Length 58CM)',NULL,NULL,'(Custom Length 58CM)',1,2,NULL,NULL,'anonymous user',1727632021,NULL),('ed2b8bdfd024488fa3d262996bd111ec','6c741acc7a0b11ef8d4b6045bd5acb12','fe0a85c9c501446bab9694bcbc7af906','Top comment4569 - 10% grind & polish - Smooth surface  remarks123','TOP','comment4569','remarks123',2,0,'anonymous user',1727793360,'anonymous user',1727793334,NULL);
/*!40000 ALTER TABLE `template_est_part` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-27 13:35:37
