-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `template_est_customer`
--

DROP TABLE IF EXISTS `template_est_customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `template_est_customer` (
  `guid` varchar(36) NOT NULL,
  `template_est_guid` varchar(36) NOT NULL,
  `customer_company_guid` varchar(36) NOT NULL,
  `update_by` varchar(45) DEFAULT NULL,
  `update_dt` bigint DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template_est_customer`
--

LOCK TABLES `template_est_customer` WRITE;
/*!40000 ALTER TABLE `template_est_customer` DISABLE KEYS */;
INSERT INTO `template_est_customer` VALUES ('1f5dd7aa26624e049a1d6611fac3e70a','66400170beb14f2cb543e9e510d07c5e','6d8fc4622e5011ef91a300ff079339a5','anonymous user',1728670306,1728670300,'anonymous user',1728670306),('254eea287983418db011c4517328ca80','d9e623f8fedf48b597d839892fcc61a7','6d8fc8822e5011ef91a300ff079339a5',NULL,NULL,1727510102,'anonymous user',NULL),('26e119785ce941afac747ed1e5b2383f','66400170beb14f2cb543e9e510d07c5e','6d8fc6722e5011ef91a300ff079339a5','anonymous user',1728670306,1727632652,'anonymous user',1728670306),('3148c1c144cc45c0b42150c9f0012c42','854a708cbaf14b12b5ffb32dd47ad8d9','6d8fbc0e2e5011ef91a300ff079339a5',NULL,NULL,1727965922,'anonymous user',NULL),('38c896bdd5b94dbd97c30914d7bbe98c','d9e623f8fedf48b597d839892fcc61a7','5d8fa7822e5011ef91a300ff079339a5',NULL,NULL,1729019614,'anonymous user',NULL),('3bb130d748824a208b593032f9a8296c','fe0a85c9c501446bab9694bcbc7af906','6d8fc6722e5011ef91a300ff079339a5','anonymous user',1728715694,1728670322,'anonymous user',1728715694),('4d40ef73a8424606b585c3984de43cd6','1','6d8fccb22e5011ef91a300ff079339a5',NULL,NULL,1729097047,'anonymous user',NULL),('50855aed4ea544d7890cf2f1a2009fb0','d9e623f8fedf48b597d839892fcc61a7','6d8fc4622e5011ef91a300ff079339a5',NULL,NULL,1727510102,'anonymous user',NULL),('59670b2fbd224bc5a8e6635059c36f8a','854a708cbaf14b12b5ffb32dd47ad8d9','6d8fc8822e5011ef91a300ff079339a5',NULL,NULL,1727965922,'anonymous user',NULL),('63caf974e3114a2e8458c5f821fb3035','66400170beb14f2cb543e9e510d07c5e','6d8fc4622e5011ef91a300ff079339a5','anonymous user',1728670306,1727632652,'anonymous user',1728670306),('75afc9c1028f461c9feb531d3e113f0b','1','6d8fbe322e5011ef91a300ff079339a5','anonymous user',1728920583,1727544364,'anonymous user',1728920583),('7dae7393bcff4e0f8d43f1e1148e2635','854a708cbaf14b12b5ffb32dd47ad8d9','5d8fa7822e5011ef91a300ff079339a5','anonymous user',1728925894,1728925762,'anonymous user',1728925894),('845f43065cca4cf1acd13df0a4155013','1','6d8fc6722e5011ef91a300ff079339a5',NULL,NULL,1728925849,'anonymous user',NULL),('875b9327cdf04c0f8bab3be085d3e413','1','5d8fa7822e5011ef91a300ff079339a5',NULL,NULL,1728925849,'anonymous user',NULL),('b05656792af34cd5996bbdbd53e9738b','66400170beb14f2cb543e9e510d07c5e','6d8fc6722e5011ef91a300ff079339a5','anonymous user',1728670306,1728670300,'anonymous user',1728670306),('b0d2539e478f4a659687e4fad8818b4e','1','6d8fc6722e5011ef91a300ff079339a5','anonymous user',1728920583,1727512061,'anonymous user',1728920583),('c567a70556174aa2b73fda84e1435d6d','d9e623f8fedf48b597d839892fcc61a7','5d8fa7822e5011ef91a300ff079339a5','anonymous user',1728925823,1728925775,'anonymous user',1728925823),('ca8d200000d14eaaa903cd20830bad9a','d9e623f8fedf48b597d839892fcc61a7','6d8fc6722e5011ef91a300ff079339a5',NULL,NULL,1727510102,'anonymous user',NULL);
/*!40000 ALTER TABLE `template_est_customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-27 13:35:38
