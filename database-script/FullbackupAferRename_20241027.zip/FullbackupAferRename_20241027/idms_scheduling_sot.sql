-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `scheduling_sot`
--

DROP TABLE IF EXISTS `scheduling_sot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scheduling_sot` (
  `guid` varchar(36) NOT NULL,
  `sot_guid` varchar(36) DEFAULT NULL,
  `scheduling_guid` varchar(36) DEFAULT NULL,
  `scheduling_dt` bigint DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `status_cv` varchar(20) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `update_by` varchar(45) DEFAULT NULL,
  `update_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheduling_sot`
--

LOCK TABLES `scheduling_sot` WRITE;
/*!40000 ALTER TABLE `scheduling_sot` DISABLE KEYS */;
INSERT INTO `scheduling_sot` VALUES ('17b3f5d4560f43e59ba3d6dca96f04ef','4bae13891a9648d7831d17b022b6fff1','8da4c0ec5d594f57b3e4109c71d456a7',1727107200,'try me','NEW',NULL,'anonymous user',1726488680,'anonymous user',1726252726,NULL),('36520c15d54d43c39792ad8b9cb5e330','fada38916c82458c96fd9ba238d5ce48','6c71567aa9e94df38a50d2ac15e4dda4',1726675200,'demo wrong date 19 sept','NEW',NULL,'anonymous user',1726301377,'anonymous user',1726271323,1726301377),('3c62a078a3fd4f6c85540e2d749c4d7c','f3996dad18764c269a8a94301312b983','d5f5c316cf674f35825fc8f08c30a23b',1726761600,'RO for demo21','MATCH',NULL,'anonymous user',1726490149,'anonymous user',1726252688,NULL),('96bb533a3df748ee8eef0d2b938e8500','df3edfaeaa0c475a889d5886240f5267','ef567aef878b48debe3556ddc68ed32f',1727452800,'REF RO 2222','NEW',NULL,NULL,NULL,'anonymous user',1727395946,NULL),('999179d092ab46358beb4c6775c4b958','fada38916c82458c96fd9ba238d5ce48','794ca5550e704136be1c87e9beeec787',1726675200,NULL,'NEW',NULL,NULL,NULL,'anonymous user',1726301388,NULL),('ac6f621b7bc64e26af6f5e6d79d61e84','c9afa144ffb64bef94bdb923fdf97497','faf7e67631384d8b91c21d31eb8360c8',1728748800,'REF NO 4567','NEW',NULL,'anonymous user',1728805373,'anonymous user',1727395335,NULL),('b5d235677e804cf5b782ef0f2a47087d','389b8f1138a14ce5b6550a3e7f79ae4a','cd1507685a5e4aa0917dbb00e52b16d3',1728921600,'','NEW',NULL,NULL,NULL,'anonymous user',1728691156,NULL),('c45527320a9a49f3b990a4e509f16098','389b8f1138a14ce5b6550a3e7f79ae4a','3d2d6bdcc7694d9680ea5bde94462f13',1729094400,'','NEW',NULL,NULL,NULL,'anonymous user',1728703639,NULL),('c512b420068240c8844bacb683e1efe3','5b545dad7bd04ec58c602077cc3f2004','faf7e67631384d8b91c21d31eb8360c8',1728748800,'REF NO 2345','NEW',NULL,'anonymous user',1728805373,'anonymous user',1727395335,NULL),('de2b86ab12ea41bd80498c4df47a120a','3161c629204645f9becc66a2dc0e7a90','faf7e67631384d8b91c21d31eb8360c8',1728748800,'REF NO 1234','NEW',NULL,'anonymous user',1728805373,'anonymous user',1727395335,NULL),('e829934b71fe488a8d3e1d7d8ff4acc8','edfb2619e974474c9435790dfc22279c','01e8d57833044cc5b154a53806b447d5',1728403200,'Ref Ro IBTT','NEW',NULL,'anonymous user',1728663218,'anonymous user',1728662977,NULL);
/*!40000 ALTER TABLE `scheduling_sot` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-27 13:36:11
