-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `storing_order`
--

DROP TABLE IF EXISTS `storing_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `storing_order` (
  `guid` varchar(36) NOT NULL,
  `customer_company_guid` varchar(36) NOT NULL,
  `so_notes` varchar(45) DEFAULT NULL,
  `so_no` varchar(20) NOT NULL,
  `haulier` varchar(45) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status_cv` varchar(20) DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `update_dt` bigint DEFAULT NULL,
  `update_by` varchar(45) DEFAULT NULL,
  `running_number` int NOT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storing_order`
--

LOCK TABLES `storing_order` WRITE;
/*!40000 ALTER TABLE `storing_order` DISABLE KEYS */;
INSERT INTO `storing_order` VALUES ('0d8467d7e4e34a1e889d30c9f8499f0d','6d8fc4622e5011ef91a300ff079339a5','this is a so note','SO24350001','','','PENDING',NULL,1724676227,'admin',NULL,NULL,1),('0f4b333b3b094214a8ca17966016fbcd','6d8fca922e5011ef91a300ff079339a5','My another notes','SO24280001','This is my haulier','','PENDING',NULL,1720947756,'admin',1720949122,'admin',1),('199d64d2cb26446381fe008f893d90f1','6d8fc8822e5011ef91a300ff079339a5','SO5','SO24280002','Haulier ABC','','COMPLETED',NULL,1720946175,'admin',1720947068,'admin',2),('2686a88f15cd4ac4af0f4a65790a1365','6d8fc4622e5011ef91a300ff079339a5','Notes 1234','SO24280003','','','PENDING',NULL,1720944402,'admin',1720944660,'admin',3),('2f6e301aaab84f0db2de10a5c9387c9d','5d8fa01e2e5011ef91a300ff079339a5','Total should have 3 tanks','SO24320003','Express Transport','','COMPLETED',NULL,1723253998,'admin',1723304550,'anonymous user',3),('461aa447e20d44da9ce3aa1ed4451f30','6d8fc6722e5011ef91a300ff079339a5','Create Preorder HBGJ 899422-0','SO24340005','Hoo Sey','Cancel','CANCELED',NULL,1724580967,'admin',1724581338,'admin',5),('467d712212a345e78cd9e3239a11050e','6d8fccb22e5011ef91a300ff079339a5','BookFace','SO24380002','','Cancel SO','PENDING',NULL,1726937563,'admin',1727969211,'admin',2),('46be3d7be362447390f5730d8d47223e','6d8fbc0e2e5011ef91a300ff079339a5','I will be back next week','SO24320004','7 Day 8 Day','','PENDING',NULL,1723300656,'admin',1724578772,'admin',4),('499b3539dce049438e81df2a93a13bd2','6d8fca922e5011ef91a300ff079339a5','So 7','SO24280004','Transport 123','Cancel SO2428004','PENDING',NULL,1720947466,'admin',1723254095,'admin',4),('4d6ba2781a5c43d8b4f230c65f17d689','6d8fbe322e5011ef91a300ff079339a5','Test preorder again ','SO24320002','Fast Deliver','','COMPLETED',NULL,1723134721,'admin',1724487790,'anonymous user',2),('5653fb4f3e08442eac85757ed12b3f07','6d8fc6722e5011ef91a300ff079339a5','My note is this','SO24340003','Hijap','','COMPLETED',NULL,1724504801,'admin',1724505371,'admin',3),('6aaf46c2863b4a8293416265033a25fc','6d8fbe322e5011ef91a300ff079339a5','Dodo notes','SO24380001','Missy Lin','','COMPLETED',NULL,1726577518,'admin',1726587156,'admin',1),('821e2f4eae164f6d927231299f86fa0b','5d8fa4f02e5011ef91a300ff079339a5','This is another so notes la','SO24350002','','','PENDING',NULL,1724676397,'admin',NULL,NULL,2),('8ea1bd8cf25548558a3b96aa94588594','6d8fccb22e5011ef91a300ff079339a5','Loliloso','SO24410001','Poli','','COMPLETED',NULL,1728393398,'admin',1728394077,'anonymous user',1),('9f1c59b29b03461a9fc33175bea04d20','5d8fa01e2e5011ef91a300ff079339a5','Book in advance again','SO24330002','','','PENDING',NULL,1723434149,'admin',1723508434,'admin',2),('a034a550adf14fbb8ac244d4cf487faf','6d8fbe322e5011ef91a300ff079339a5','SO 3','SO24280005','Transport ABC','','PENDING',NULL,1720945470,'admin',1724373013,'admin',5),('a40f65c801a841d8b002a9ed0aa0e669','6d8fc8822e5011ef91a300ff079339a5','NOTES','SO24280006','Haulier 033','','PROCESSING',NULL,1720947388,'admin',1723130730,'anonymous user',6),('a7086f3e10b24eceb4024708da691de9','6d8fbc0e2e5011ef91a300ff079339a5','SO6','SO24280007','Fast Transport','','PROCESSING',NULL,1720946826,'admin',1723131356,'anonymous user',7),('ab45792008d545058dfb15f5b09826f2','5d8fa7822e5011ef91a300ff079339a5','Tela','SO24410002','Brolico','','COMPLETED',NULL,1728396269,'admin',1728396588,'anonymous user',2),('b7660bdb4bbb457eae9200b72e5d704a','5d8fa4f02e5011ef91a300ff079339a5','SO4','SO24280008','Fast Transport','','PROCESSING',NULL,1720945949,'admin',1724371710,'admin',8),('b7d8ccd9a8824d49b747a733aa57275c','6d8fca922e5011ef91a300ff079339a5','There is no Note for this','SO24340001','DHL Pte Ltd','','COMPLETED',NULL,1724073122,'admin',1724073169,'anonymous user',1),('c7a57eb236434611a79baea42d9cb008','6d8fbe322e5011ef91a300ff079339a5','Insert For Testing','SO24340002','Fast Deliver','','COMPLETED',NULL,1724486337,'admin',1724486815,'admin',2),('cc069ef39e304e22a38af1d9e8be4339','6d8fbc0e2e5011ef91a300ff079339a5','Book in advance','SO24330001','','cancel','CANCELED',NULL,1723434054,'admin',1724580084,'admin',1),('ccd91d8dd51449b9bbea50b9ea8a4a22','5d8fa4f02e5011ef91a300ff079339a5','Nonotes','SO24280009','Haulier Inggg','','PROCESSING',NULL,1720948831,'admin',1720948873,'admin',9),('cd6a24f9194c409d948d7c43196d809b','6d8fc6722e5011ef91a300ff079339a5','Test preorder','SO24320001','Hitachi','Cancel SO','COMPLETED',NULL,1723132101,'admin',1723964781,'anonymous user',1),('d678fc571615457c8ce9cd8c9ae8f3ac','6d8fc6722e5011ef91a300ff079339a5','Lamo','SO24410003','Jikopek','','COMPLETED',NULL,1728396993,'admin',1728397028,'anonymous user',3),('f330d52938fc4978af558959cc3ba78c','6d8fc6722e5011ef91a300ff079339a5','Use standard categories','SO24280010','Transport Express','','PROCESSING',NULL,1720943416,'admin',1724487341,'admin',10),('f88bfd1bb7654f3887812e1b7b837d30','6d8fc4622e5011ef91a300ff079339a5','No Bi Ta','SO24370001','Tan Ku Ku','','COMPLETED',NULL,1725858216,'admin',1726502125,'admin',1),('fb65693401894f999884faf018b49ebc','6d8fc6722e5011ef91a300ff079339a5','This is the note','SO24340004','HouYeah','','PENDING',NULL,1724506924,'admin',1724578493,'admin',4),('fe82bc9b551e426996093b3381eaec40','5d8fa4f02e5011ef91a300ff079339a5','Need to perform preorder','SO24330003','','','PENDING',NULL,1723443687,'admin',NULL,NULL,3);
/*!40000 ALTER TABLE `storing_order` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`idms_admin`@`%`*/ /*!50003 TRIGGER `trg_before_insert_storing_order` BEFORE INSERT ON `storing_order` FOR EACH ROW BEGIN
    DECLARE max_number INT;
    DECLARE current_year CHAR(2);
    DECLARE current_week CHAR(2);
    DECLARE current_dt DATETIME;

    -- Convert epoch time to datetime
    SET current_dt = FROM_UNIXTIME(NEW.create_dt);

    -- Get the current year and week number
    SET current_year = DATE_FORMAT(current_dt, '%y');
    SET current_week = LPAD(WEEK(current_dt, 1), 2, '0'); -- ISO week

    -- Get the current maximum running number for the year and week
    SELECT COALESCE(MAX(running_number), 0) + 1 INTO max_number
    FROM storing_order
    WHERE YEAR(FROM_UNIXTIME(create_dt)) = YEAR(current_dt)
    AND WEEK(FROM_UNIXTIME(create_dt), 1) = WEEK(current_dt, 1);

    -- Set the running number
    SET NEW.running_number = max_number;

    -- Generate the SO_NO
    SET NEW.so_no = CONCAT('SO', current_year, current_week, LPAD(max_number, 4, '0'));
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-27 13:35:35
