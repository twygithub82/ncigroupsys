-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `repair`
--

DROP TABLE IF EXISTS `repair`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repair` (
  `guid` varchar(36) NOT NULL,
  `sot_guid` varchar(36) NOT NULL,
  `aspnetusers_guid` varchar(36) NOT NULL,
  `estimate_no` varchar(20) NOT NULL,
  `labour_cost_discount` double NOT NULL DEFAULT '0',
  `material_cost_discount` double NOT NULL DEFAULT '0',
  `labour_cost` double NOT NULL DEFAULT '0',
  `total_cost` double NOT NULL DEFAULT '0',
  `status_cv` varchar(20) NOT NULL COMMENT 'code_val_type = REP_EST_STATUS',
  `remarks` varchar(150) DEFAULT NULL,
  `owner_enable` tinyint NOT NULL DEFAULT '0',
  `bill_to_guid` varchar(36) DEFAULT NULL,
  `job_no` varchar(45) DEFAULT NULL COMMENT 'each estimate have its own job no',
  `total_hour` double DEFAULT '0',
  `approve_dt` bigint DEFAULT NULL,
  `update_dt` bigint DEFAULT NULL,
  `update_by` varchar(45) DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  `running_number` int NOT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repair`
--

LOCK TABLES `repair` WRITE;
/*!40000 ALTER TABLE `repair` DISABLE KEYS */;
INSERT INTO `repair` VALUES ('09ba7e4de6cc4cfeb982499918e50d28','f3996dad18764c269a8a94301312b983','fb980647-fb81-465f-a0d4-28c31701a554','RE24420002',10,10,30,465.62,'PENDING','This remarks will show at repair estimate',0,NULL,NULL,0,NULL,1728997324,'anonymous user',1728926922,'anonymous user',NULL,2),('16307a3a849e4465878c94ae71a18583','389b8f1138a14ce5b6550a3e7f79ae4a','fb980647-fb81-465f-a0d4-28c31701a554','RE24410004',2,1,20,196,'APPROVED','Supplementary would be raised if more damages are seen',0,'5d8fa7822e5011ef91a300ff079339a5',NULL,2,NULL,1729727125,'anonymous user',1728755808,'anonymous user',NULL,4),('184da71ab52b4a81a0d2a555bfe2af70','459535932b8340b4a572d7aea58bdbad','fb980647-fb81-465f-a0d4-28c31701a554','RE24390004',10,10,45,247,'PENDING','try cancel - try rollback',1,NULL,NULL,0,NULL,1728918160,'anonymous user',1727637945,'anonymous user',NULL,4),('440b6bf15e634c53b94029ddc132293d','4bae13891a9648d7831d17b022b6fff1','fb980647-fb81-465f-a0d4-28c31701a554','RE24420009',10,10,30,30.5,'PENDING','This Remarks will show at Estimate Repair...',0,NULL,NULL,0,NULL,NULL,NULL,1729096014,'anonymous user',NULL,9),('46e1f349b9284823ac6d474c77f0a972','4bae13891a9648d7831d17b022b6fff1','fb980647-fb81-465f-a0d4-28c31701a554','RE24410006',10,10,45,176,'PENDING','This remarks will show at repair estimate',0,NULL,NULL,0,NULL,1728861632,'anonymous user',1728861502,'anonymous user',NULL,6),('532f2b1fb31a4c16bbef3e08a7830bcc','389b8f1138a14ce5b6550a3e7f79ae4a','fb980647-fb81-465f-a0d4-28c31701a554','RE24410003',0,0,20,293,'PENDING','Remarks for repair estimate',1,NULL,NULL,0,NULL,1728900619,'anonymous user',1728707381,'anonymous user',NULL,3),('5724ea03004847f4aa7760860d0943c7','656f767505304968881a97a0747ab0a8','fb980647-fb81-465f-a0d4-28c31701a554','RE24420008',0,0,30,360,'PENDING',NULL,0,NULL,NULL,0,NULL,1729097218,'anonymous user',1729020627,'anonymous user',NULL,8),('69c99a7b7ee145abbf3c654bf2f50c35','389b8f1138a14ce5b6550a3e7f79ae4a','fb980647-fb81-465f-a0d4-28c31701a554','RE24410002',0,0,20,496,'PENDING',NULL,0,NULL,NULL,0,NULL,1728861458,'anonymous user',1728707267,'anonymous user',NULL,2),('8c429e124db84f68a6ccd295d9a00a42','459535932b8340b4a572d7aea58bdbad','fb980647-fb81-465f-a0d4-28c31701a554','RE24390002',10,10,45,336,'CANCELED','This remarks will show at repair estimate - cancel now',0,NULL,NULL,0,NULL,1728576327,'anonymous user',1727550607,'anonymous user',NULL,2),('91fd5b1a842941cd8b183238e5dac59a','389b8f1138a14ce5b6550a3e7f79ae4a','fb980647-fb81-465f-a0d4-28c31701a554','RE24420007',10,10,30,723.2,'PENDING','Supplementary would be raised if more damages are seen',0,NULL,NULL,0,NULL,NULL,NULL,1729020581,'anonymous user',NULL,7),('9accab50685443969fb15efd199d7d60','5b545dad7bd04ec58c602077cc3f2004','fb980647-fb81-465f-a0d4-28c31701a554','RE24420005',0,0,30,30.5,'PENDING','copy de',0,NULL,NULL,0,NULL,NULL,NULL,1729004144,'anonymous user',NULL,5),('a0f77fd6d0d14f35a6ca8464f9151b88','3161c629204645f9becc66a2dc0e7a90','fb980647-fb81-465f-a0d4-28c31701a554','RE24420004',10,10,30,35.5,'PENDING','This Remarks will show at Estimate Repair...',0,NULL,NULL,0,NULL,NULL,NULL,1729003894,'anonymous user',NULL,4),('a371deecaacf49e083531f6a8e46176e','fada38916c82458c96fd9ba238d5ce48','fb980647-fb81-465f-a0d4-28c31701a554','RE24420001',10,10,30,763.5,'PENDING','This Remarks will show at Estimate Repair...',1,NULL,NULL,0,NULL,1728921011,'anonymous user',1728917703,'anonymous user',NULL,1),('b0cab8d22d15470690ce4d8402e6f539','f3996dad18764c269a8a94301312b983','fb980647-fb81-465f-a0d4-28c31701a554','RE24390001',10,10,48,466,'PENDING','This remarks will show at repair estimate',0,NULL,NULL,0,NULL,1728926498,'anonymous user',1727547162,'anonymous user',NULL,1),('d018544d63304e3d9b6c70cc5249d87d','389b8f1138a14ce5b6550a3e7f79ae4a','fb980647-fb81-465f-a0d4-28c31701a554','RE24410005',10,10,20,351,'PENDING','This remarks will show at repair estimate',0,NULL,NULL,0,NULL,1728920761,'anonymous user',1728844836,'anonymous user',NULL,5),('dea4509d56f74de5899721578e9d8e70','459535932b8340b4a572d7aea58bdbad','fb980647-fb81-465f-a0d4-28c31701a554','RE24400002',2,1,45,58,'PENDING','try change default - the customer cancel again',0,'6d8fbe322e5011ef91a300ff079339a5',NULL,0,NULL,1728806064,'anonymous user',1728042685,'anonymous user',NULL,2),('e1c4db16c29848d4a95a1cea37a47299','f3996dad18764c269a8a94301312b983','fb980647-fb81-465f-a0d4-28c31701a554','RE24390003',0,0,48,47,'PENDING',NULL,0,NULL,NULL,0,NULL,NULL,NULL,1727551398,'anonymous user',NULL,3),('e36db1b3df03402c8cc48850074ed835','f3996dad18764c269a8a94301312b983','fb980647-fb81-465f-a0d4-28c31701a554','RE24420006',10,10,30,135.5,'PENDING','This Remarks will show at Estimate Repair...',0,NULL,NULL,0,NULL,1729012012,'anonymous user',1729009367,'anonymous user',NULL,6),('e383bb5a99d14e2aad5210c58551c48f','f3996dad18764c269a8a94301312b983','fb980647-fb81-465f-a0d4-28c31701a554','RE24410001',0,0,48,94,'CANCELED','Cancel',0,NULL,NULL,0,NULL,1728671056,'anonymous user',1728670892,'anonymous user',NULL,1),('f6d545aeacb44bae935fcd74d89193f9','459535932b8340b4a572d7aea58bdbad','fb980647-fb81-465f-a0d4-28c31701a554','RE24400001',10,10,45,146,'PENDING','This Remarks will show at Estimate Repair...',0,NULL,NULL,0,NULL,NULL,NULL,1728041931,'anonymous user',NULL,1);
/*!40000 ALTER TABLE `repair` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`idms_admin`@`%`*/ /*!50003 TRIGGER `trg_before_insert_repair` BEFORE INSERT ON `repair` FOR EACH ROW BEGIN
    DECLARE max_number INT;
    DECLARE current_year CHAR(2);
    DECLARE current_week CHAR(2);
    DECLARE current_dt DATETIME;

    -- Convert epoch time to datetime
    SET current_dt = FROM_UNIXTIME(NEW.create_dt);

    -- Get the current year and week number
    SET current_year = DATE_FORMAT(current_dt, '%y');
    SET current_week = LPAD(WEEK(current_dt, 1), 2, '0'); -- ISO week

    -- Get the current maximum running number for the year and week
    SELECT COALESCE(MAX(running_number), 0) + 1 INTO max_number
    FROM repair
    WHERE YEAR(FROM_UNIXTIME(create_dt)) = YEAR(current_dt)
    AND WEEK(FROM_UNIXTIME(create_dt), 1) = WEEK(current_dt, 1);

    -- Set the running number
    SET NEW.running_number = max_number;

    -- Generate the RO_NO
    SET NEW.estimate_no = CONCAT('RE', current_year, current_week, LPAD(max_number, 4, '0'));
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-27 13:36:21
