-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer_company`
--

DROP TABLE IF EXISTS `customer_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_company` (
  `guid` varchar(36) NOT NULL,
  `currency_guid` varchar(36) DEFAULT NULL,
  `def_template_guid` varchar(36) DEFAULT NULL,
  `main_customer_guid` varchar(36) DEFAULT NULL COMMENT 'to store the main customer guid which also a custome company',
  `type_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = CUSTOMER_TYPE',
  `name` varchar(50) DEFAULT NULL,
  `code` varchar(10) DEFAULT NULL,
  `address_line1` varchar(255) DEFAULT NULL,
  `address_line2` varchar(255) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `postal` varchar(20) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `website` varchar(45) DEFAULT NULL,
  `effective_dt` bigint DEFAULT NULL,
  `agreement_due_dt` bigint DEFAULT NULL,
  `remarks` varchar(120) DEFAULT NULL,
  `def_tank_guid` varchar(36) DEFAULT NULL COMMENT 'to store the default profile (tank) for the customer',
  `update_dt` bigint DEFAULT NULL,
  `update_by` varchar(45) DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`),
  UNIQUE KEY `code_UNIQUE` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_company`
--

LOCK TABLES `customer_company` WRITE;
/*!40000 ALTER TABLE `customer_company` DISABLE KEYS */;
INSERT INTO `customer_company` VALUES ('1849ba8ecb9b4f9683d40a2af236817c','123e4567e89b12d3a456426655440000',NULL,'','BRANCH','ABC BRANCH','ZAE','fdfsdfsd','','','Singapore','4234234','+9123456788','yahoo@branch.com','yahoo@branch.com',NULL,NULL,'','706928282e5411ef91a300ff079339a5',1729015756,'anonymous user',1728918589,'anonymous user',NULL),('3d4b63d9621d406f96cf52f33aa684a4','123e4567e89b12d3a456426655440000',NULL,'6d8fbe322e5011ef91a300ff079339a5','BRANCH','Branch 123','ZAA','fsdfsgsg','','','Singapore','342342','+1-282-000-2000','fsdfs@fdfas.com','fsdfs@fdfas.com',NULL,NULL,'','706928282e5411ef91a300ff079339a5',1728919171,'anonymous user',NULL,NULL,NULL),('55edec980d1c42f0a2a48ca43acd85f7','123e4567e89b12d3a456426655440000',NULL,'','BRANCH','TransNation Trade Ltd.','TNT','1 Orchard','','Singapore','Singapore','248649','88227744','info@TNT.com','info@TNT.com',NULL,NULL,'AWL Branch','70691e542e5411ef91a300ff079339a5',1729015686,'anonymous user',1728932297,'anonymous user',NULL),('5d8f899e2e5011ef91a300ff079339a5','123e4567e89b12d3a456426655440001','66400170beb14f2cb543e9e510d07c5e',NULL,'OWNER','Tech Innovations Ltd.','TIL','123 Tech Park','Suite 400','San Francisco','USA','94107','+1-800-555-0100','info@techinnov.com','https://www.techinnov.com',1704038400,1735660800,'A leading technology solutions provider',NULL,1718810817,'admin',1701360000,'admin',NULL),('5d8fa01e2e5011ef91a300ff079339a5','123e4567e89b12d3a456426655440001','66400170beb14f2cb543e9e510d07c5e',NULL,'OWNER','Global Trade Corp.','GTC','456 Market St','Floor 5','New York','USA','10005','+1-800-555-0300','contact@globaltrade.com','https://www.globaltrade.com',1682870400,1714492800,'International trading company specializing in raw materials',NULL,1714492800,'admin',1680278400,'admin',NULL),('5d8fa4f02e5011ef91a300ff079339a5','123e4567e89b12d3a456426655440001','66400170beb14f2cb543e9e510d07c5e',NULL,'OWNER','Eco Solutions Inc.','ESI','789 Green Way','Building 2','Austin','USA','73301','+1-800-555-0500','support@ecosolutions.com','https://www.ecosolutions.com',1693497600,1725120000,'Sustainable energy solutions provider',NULL,1718810817,'admin',1690819200,'admin',NULL),('5d8fa7822e5011ef91a300ff079339a5','123e4567e89b12d3a456426655440001','d9e623f8fedf48b597d839892fcc61a7',NULL,'OWNER','MediCare Health Ltd.','MCH','123 Wellness Blvd','Room 101','Chicago','USA','60601','+1-800-555-0700','info@medicare.com','https://www.medicare.com',1709222400,1740758400,'Provider of healthcare and medical services',NULL,1729020581,'anonymous user',1675180800,'admin',NULL),('5d8faa9d2e5011ef91a300ff079339a5','123e4567e89b12d3a456426655440001','66400170beb14f2cb543e9e510d07c5e',NULL,'OWNER','NextGen Automotive','NGA','456 Drive St','Suite 202','Detroit','USA','48201','+1-800-555-0900','sales@nextgenauto.com','https://www.nextgenauto.com',1688140800,1719763200,'Manufacturer of electric vehicles and components',NULL,1718810817,'admin',1685548800,'admin',NULL),('6d8fb9de2e5011ef91a300ff079339a5','123e4567e89b12d3a456426655440001','66400170beb14f2cb543e9e510d07c5e',NULL,'OWNER','Tech Innovators Co.','TIC','789 Innovation Drive','Suite 500','Silicon Valley','USA','94027','+1-800-555-1100','contact@techinnovco.com','https://www.techinnovco.com',1704038401,1735660801,'Pioneers in tech innovations',NULL,1718810818,'admin',1701360001,'admin',NULL),('6d8fbc0e2e5011ef91a300ff079339a5','123e4567e89b12d3a456426655440001','66400170beb14f2cb543e9e510d07c5e',NULL,'OWNER','Global Logistics Inc.','GLI','321 Freight St','Floor 6','Miami','USA','33101','+1-800-555-1300','info@globallog.com','https://www.globallog.com',1682870401,1714492801,'Leading provider of global logistics services',NULL,1718810818,'admin',1680278401,'admin',NULL),('6d8fbe322e5011ef91a300ff079339a5','123e4567e89b12d3a456426655440001','66400170beb14f2cb543e9e510d07c5e',NULL,'OWNER','Eco Energy Solutions','EES','123 Solar Park','Building 3','San Diego','USA','92101','+1-800-555-1500','support@ecoenergy.com','https://www.ecoenergy.com',1693497601,1725120001,'Renewable energy solutions provider',NULL,1729096014,'anonymous user',1690819201,'admin',NULL),('6d8fc0422e5011ef91a300ff079339a5','123e4567e89b12d3a456426655440001','66400170beb14f2cb543e9e510d07c5e',NULL,'OWNER','MediCare Global Ltd.','MGL','456 Wellness Avenue','Room 202','Los Angeles','USA','90001','+1-800-555-1700','info@medicareglobal.com','https://www.medicareglobal.com',1709222401,1740758401,'Global provider of healthcare services',NULL,1718810818,'admin',1675180801,'admin',NULL),('6d8fc2522e5011ef91a300ff079339a5','123e4567e89b12d3a456426655440001','66400170beb14f2cb543e9e510d07c5e',NULL,'OWNER','NextGen Technologies','NGT','789 Future Blvd','Suite 303','Seattle','USA','98101','+1-800-555-1900','sales@nextgentech.com','https://www.nextgentech.com',1688140801,1719763201,'Next-generation tech solutions provider',NULL,1718810818,'admin',1685548801,'admin',NULL),('6d8fc4622e5011ef91a300ff079339a5','123e4567e89b12d3a456426655440001','66400170beb14f2cb543e9e510d07c5e',NULL,'OWNER','BioHealth Innovations','BHI','123 Health St','Floor 4','Boston','USA','02108','+1-800-555-2100','info@biohealth.com','https://www.biohealth.com',1698768001,1730390401,'Innovative healthcare solutions provider',NULL,1718810818,'admin',1696070401,'admin',NULL),('6d8fc6722e5011ef91a300ff079339a5','123e4567e89b12d3a456426655440001','1','','OWNER','AgriWorld Ltd.','AWL','456 Farm Road','Suite 404','Dallas','USA','75201','+1-800-555-2109','contact@agriworld.com','www.agriworld.com',1709395201,1741017601,'Provider of agricultural solutions','70691e542e5411ef91a300ff079339a5',1729016219,'anonymous user',NULL,NULL,NULL),('6d8fc8822e5011ef91a300ff079339a5','123e4567e89b12d3a456426655440001',NULL,NULL,'OWNER','FutureTech Corp.','FTC','789 Progress Ave','Room 505','Denver','USA','80202','+1-800-555-2500','info@futuretech.com','https://www.futuretech.com',1719849601,1751472001,'Cutting-edge technology solutions','706921cd2e5411ef91a300ff079339a5',1729048700,'anonymous user',1717171201,'admin',NULL),('6d8fca922e5011ef91a300ff079339a5','123e4567e89b12d3a456426655440001','66400170beb14f2cb543e9e510d07c5e',NULL,'OWNER','GreenWorld Solutions','GWS','123 Greenway','Suite 606','Portland','USA','97201','+1-800-555-2700','support@greenworld.com','https://www.greenworld.com',1722480001,1754102401,'Provider of green technology solutions',NULL,1729003894,'anonymous user',1719811201,'admin',NULL),('6d8fccb22e5011ef91a300ff079339a5','123e4567e89b12d3a456426655440001','1',NULL,'OWNER','InnoBioTech Ltd.','IBT','456 Bio Rd','Floor 7','San Jose','USA','95101','+1-800-555-2900','info@innobiotech.com','https://www.innobiotech.com',1730294401,1761916801,'Innovative biotech solutions',NULL,1729097066,'anonymous user',1727616001,'admin',NULL),('7253d295c76a4e038b413e08d8d9fe52','123e4567e89b12d3a456426655440000',NULL,'6d8fc6722e5011ef91a300ff079339a5','BRANCH','Demo Pte Ltd','DMO','1 Orchard','','Singapore','Singapore','283555','82947566','demo@gmail.com','www.demo.com',NULL,NULL,'AWL Branch','706921cd2e5411ef91a300ff079339a5',NULL,NULL,1729016210,'anonymous user',NULL),('bc5de37e01724123a9b864f1e686a683','123e4567e89b12d3a456426655440000',NULL,NULL,'OWNER','Branch T','ZAB','97 ubi ave 4','','','Singapore','6565','423423455','5454@545.com','',NULL,NULL,'','706928e12e5411ef91a300ff079339a5',1729001297,'anonymous user',1728919324,'anonymous user',NULL),('c9147a2a55da4a77ac47b0e01d21868b','123e4567e89b12d3a456426655440000',NULL,'bc5de37e01724123a9b864f1e686a683','BRANCH','Branch 567','ZAD','fsfsdfsdfs','','','Singapore','32423423','4243356564','234fdsfs@fdsdf.com','234fdsfs@fdsdf.com',NULL,NULL,'','706928e12e5411ef91a300ff079339a5',1729001297,'anonymous user',NULL,NULL,NULL);
/*!40000 ALTER TABLE `customer_company` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`idms_admin`@`%`*/ /*!50003 TRIGGER `customer_company_AFTER_INSERT` AFTER INSERT ON `customer_company` FOR EACH ROW BEGIN
    -- Call the stored procedure and pass parameters from the NEW row
	-- IF NEW.type_cv = "BRANCH"  THEN
		 CALL SP_New_Customer_CleaningCategory(NEW.guid, NEW.create_by, NEW.create_dt);
		 CALL SP_New_Customer_PackageBuffer(NEW.guid, NEW.create_by, NEW.create_dt);    
		 CALL SP_New_Customer_PackageDepot(NEW.guid, NEW.create_by, NEW.create_dt);  
		 CALL SP_New_Customer_PackageLabour(NEW.guid, NEW.create_by, NEW.create_dt); 
		 CALL SP_New_Customer_PackageRepair(NEW.guid, NEW.create_by, NEW.create_dt); 
		 CALL SP_New_Customer_PackageResidue(NEW.guid, NEW.create_by, NEW.create_dt);
     -- END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`idms_admin`@`%`*/ /*!50003 TRIGGER `customer_company_AFTER_UPDATE` AFTER UPDATE ON `customer_company` FOR EACH ROW BEGIN
  -- Check if the delete_dt field has changed
    IF (OLD.delete_dt <> NEW.delete_dt) THEN
        -- Call the stored procedure if delete_dt is updated
        CALL SP_Del_Customer_CleaningCategory(NEW.guid, NEW.update_by, NEW.update_dt);
		CALL SP_Del_Customer_PackageBuffer(NEW.guid, NEW.update_by, NEW.update_dt);
	    CALL SP_Del_Customer_PackageDepot(NEW.guid, NEW.update_by, NEW.update_dt);
	    CALL SP_Del_Customer_PackageLabour(NEW.guid, NEW.update_by, NEW.update_dt);
	    CALL SP_Del_Customer_PackageRepair(NEW.guid, NEW.update_by, NEW.update_dt);
	    CALL SP_Del_Customer_PackageResidue(NEW.guid, NEW.update_by, NEW.update_dt);
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-27 13:35:59
