-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cleaning_category`
--

DROP TABLE IF EXISTS `cleaning_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cleaning_category` (
  `guid` varchar(36) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(45) DEFAULT NULL,
  `cost` double DEFAULT NULL,
  `sequence` int DEFAULT NULL,
  `update_dt` bigint DEFAULT NULL,
  `update_by` varchar(45) DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cleaning_category`
--

LOCK TABLES `cleaning_category` WRITE;
/*!40000 ALTER TABLE `cleaning_category` DISABLE KEYS */;
INSERT INTO `cleaning_category` VALUES ('0753dfa8e33c425584b905c3649019fa','SPECIAL4','SPECIAL4',240,7,NULL,NULL,1719389596,'anonymous user',NULL),('123e4567e89b12d3a4564266141741fc','SPECIAL6','SPECIAL 6',280,9,1625151600,'user1',1625075200,'user1',NULL),('234f5678f89c23d4b5675367252850fd','SPECIAL7','SPECIAL 7',300,10,1625238000,'user2',1625151600,'user2',NULL),('345g6789g89d34e5c6786468363960fe','SPECIAL8','SPECIAL 8',320,11,1722516222,'anonymous user',1625238000,'user3',NULL),('37af3c367ae547018fc1b7d3f0d5b94f','SPECIAL3','SPECIAL3',220,6,NULL,NULL,1719389586,'anonymous user',NULL),('57d5f47af59b498ab0629d383c969e0d','SPECIAL1','SPECIAL1',180,4,NULL,NULL,1719389530,'anonymous user',NULL),('6342cef5aadb4402bcdfbaed0de21c0b','STANDARD','STANDARD',142,2,1725559455,'anonymous user',1719389511,'anonymous user',NULL),('8620aa3a32d3447cbfa33f74b11a862a','EASY','EASY',120,1,1722516207,'anonymous user',1719389499,'anonymous user',NULL),('a2a655d27ca94b3ebcc41f3413ba412e','SPECIAL2','SPECIAL2',200,5,NULL,NULL,1719389580,'anonymous user',NULL),('d4742f64c54e43a18bee4e14650ee1fb','SPECIAL5','SPECIAL5',260,8,NULL,NULL,1719389606,'anonymous user',NULL),('fe6b28da36704c3e826e9a368572b876','SPECIAL10','SPECIAL10',450,12,NULL,NULL,1721520887,'anonymous user',NULL),('ff4170239a2845e8be7a59bb2c14ca6c','DIFFICULT','DIFFICULT',160,3,NULL,NULL,1719389520,'anonymous user',NULL);
/*!40000 ALTER TABLE `cleaning_category` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`idms_admin`@`%`*/ /*!50003 TRIGGER `cleaning_category_AFTER_INSERT` AFTER INSERT ON `cleaning_category` FOR EACH ROW BEGIN
 -- Declare cursor and variables
    DECLARE done INT DEFAULT FALSE;
    DECLARE cus_guid VARCHAR(36);
    DECLARE c_category_guid VARCHAR(36);

    -- Declare cursor
    DECLARE cur CURSOR FOR
        SELECT guid FROM customer_company WHERE (delete_dt IS NULL OR delete_dt = 0);
        
    -- Declare continue handler for cursor
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    -- Open cursor
    OPEN cur;
    -- Loop through cursor
    read_loop: LOOP
        FETCH cur INTO cus_guid;
        IF done THEN
            LEAVE read_loop;
        END IF;

	 SET c_category_guid = (REPLACE(UUID(), '-', ''));
	 INSERT INTO customer_company_cleaning_category (
		guid,
		cleaning_category_guid,
		customer_company_guid,
		initial_price,
        adjusted_price,
		create_dt,
		create_by
	  )
	  VALUES (
		c_category_guid,
		NEW.guid,
		cus_guid,
		NEW.cost,
        NEW.cost,
		NEW.create_dt,
		NEW.create_by
	  );
              
    END LOOP;
    -- Close cursor
    CLOSE cur;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-27 13:36:25
