-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `out_gate_survey`
--

DROP TABLE IF EXISTS `out_gate_survey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `out_gate_survey` (
  `guid` varchar(36) NOT NULL,
  `out_gate_guid` varchar(36) DEFAULT NULL COMMENT 'get last cargo from here',
  `capacity` int DEFAULT NULL,
  `tare_weight` int DEFAULT NULL,
  `take_in_reference` varchar(15) DEFAULT NULL,
  `last_test_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = TEST_TYPE',
  `next_test_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = TEST_TYPE',
  `test_dt` bigint DEFAULT NULL,
  `test_class_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = TEST_CLASS',
  `dom_dt` bigint DEFAULT NULL,
  `inspection_dt` bigint DEFAULT NULL,
  `last_release_dt` bigint DEFAULT NULL,
  `manufacturer_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = MANUFACTURER',
  `cladding_cv` varchar(20) DEFAULT NULL,
  `max_weight_cv` varchar(20) DEFAULT NULL,
  `height_cv` varchar(20) DEFAULT NULL,
  `walkway_cv` varchar(20) DEFAULT NULL,
  `tank_comp_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = TANK_COMP_TYPE',
  `btm_dis_comp_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = DIS_COMP',
  `btm_dis_valve_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = DIS_VALVE',
  `btm_valve_brand_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = VALVE_BRAND',
  `btm_dis_valve_spec_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = DIS_VALVE_SPEC',
  `top_dis_comp_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = DIS_COMP',
  `top_dis_valve_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = DIS_VALVE',
  `top_valve_brand_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = VALVE_BRAND',
  `top_dis_valve_spec_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = DIS_VALVE_SPEC',
  `manlid_comp_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = DIS_COMP',
  `foot_valve_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = FOOT_VALVE',
  `thermometer` int DEFAULT NULL,
  `thermometer_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = THERMOMETER',
  `ladder` tinyint DEFAULT NULL,
  `data_csc_transportplate` tinyint DEFAULT NULL,
  `airline_valve_pcs` int DEFAULT NULL,
  `airline_valve_dim` float DEFAULT NULL,
  `airline_valve_cv` varchar(20) DEFAULT NULL,
  `airline_valve_conn_cv` varchar(20) DEFAULT NULL,
  `airline_valve_conn_spec_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = MANLID_COVER',
  `manlid_cover_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = MANLID_COVER',
  `manlid_cover_pcs` int DEFAULT NULL,
  `manlid_cover_pts` int DEFAULT NULL,
  `manlid_seal_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = MANLID_SEAL',
  `pv_type_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = PV_TYPE',
  `pv_spec_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = PV_SPEC',
  `pv_type_pcs` int DEFAULT NULL,
  `pv_spec_pcs` int DEFAULT NULL,
  `safety_handrail` tinyint DEFAULT NULL,
  `buffer_plate` int DEFAULT NULL,
  `residue` float DEFAULT NULL,
  `dipstick` tinyint DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `update_dt` bigint DEFAULT NULL,
  `update_by` varchar(45) DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  `top_coord` json DEFAULT NULL,
  `bottom_coord` json DEFAULT NULL,
  `front_coord` json DEFAULT NULL,
  `rear_coord` json DEFAULT NULL,
  `left_coord` json DEFAULT NULL,
  `right_coord` json DEFAULT NULL,
  `top_remarks` varchar(120) DEFAULT NULL,
  `bottom_remarks` varchar(120) DEFAULT NULL,
  `front_remarks` varchar(120) DEFAULT NULL,
  `rear_remarks` varchar(120) DEFAULT NULL,
  `left_remarks` varchar(120) DEFAULT NULL,
  `rigth_remarks` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `out_gate_survey`
--

LOCK TABLES `out_gate_survey` WRITE;
/*!40000 ALTER TABLE `out_gate_survey` DISABLE KEYS */;
/*!40000 ALTER TABLE `out_gate_survey` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-27 13:36:06
