-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: tlx-idms.mysql.database.azure.com    Database: idms
-- ------------------------------------------------------
-- Server version	8.0.37-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `booking`
--

DROP TABLE IF EXISTS `booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking` (
  `guid` varchar(36) NOT NULL,
  `sot_guid` varchar(36) DEFAULT NULL,
  `surveyor_guid` varchar(36) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `book_type_cv` varchar(20) DEFAULT NULL,
  `status_cv` varchar(20) DEFAULT NULL COMMENT 'code_val_type = BOOKING_STATUS',
  `remarks` varchar(255) DEFAULT NULL,
  `booking_dt` bigint DEFAULT NULL,
  `update_dt` bigint DEFAULT NULL,
  `update_by` varchar(45) DEFAULT NULL,
  `create_dt` bigint DEFAULT NULL,
  `create_by` varchar(45) DEFAULT NULL,
  `delete_dt` bigint DEFAULT NULL,
  PRIMARY KEY (`guid`),
  UNIQUE KEY `guid_UNIQUE` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking`
--

LOCK TABLES `booking` WRITE;
/*!40000 ALTER TABLE `booking` DISABLE KEYS */;
INSERT INTO `booking` VALUES ('2d4dddd4d1e1479d95c89691789db785','edfb2619e974474c9435790dfc22279c','surveyor_guid_222','RO Ref ','RELEASE_ORDER','NEW',NULL,1728835200,1728662844,'anonymous user',1728662831,'anonymous user',1728662844),('3adf205a45a54779be11f431372cfb04','edfb2619e974474c9435790dfc22279c','surveyor_guid_222',NULL,'RELEASE_ORDER','NEW',NULL,1728835200,1728664838,'anonymous user',1728664831,'anonymous user',1728664838),('4b7efb14fd9c431c94e90b6d98429edf','fada38916c82458c96fd9ba238d5ce48','surveyor_guid_222',NULL,'RELEASE_ORDER','NEW',NULL,1726588800,NULL,NULL,1726301211,'anonymous user',NULL),('56ae1941a72c4a698e55c5a271ea66ed','edfb2619e974474c9435790dfc22279c','surveyor_guid_222',NULL,'X-RAY_TEST','NEW',NULL,1728921600,NULL,NULL,1728665629,'anonymous user',NULL),('8654d89d62f74a599ce9565bd307327f','389b8f1138a14ce5b6550a3e7f79ae4a','surveyor_guid_222',NULL,'X-RAY_TEST','NEW',NULL,1728921600,NULL,NULL,1728666074,'anonymous user',NULL),('bbec07aac86d4ecdab6a7e81cfaeae4f','edfb2619e974474c9435790dfc22279c','surveyor_guid_222','Ref RO','RELEASE_ORDER','NEW',NULL,1728835200,NULL,NULL,1728662866,'anonymous user',NULL),('c1f673bc5db94bdab50b184e84a0eb5f','4bae13891a9648d7831d17b022b6fff1','surveyor_guid_222','RO for demo','RELEASE_ORDER','MATCH',NULL,1727107200,1726271372,'system',1726252657,'anonymous user',NULL),('cfb8ba89ee124037b6943595e57b3ae5','f3996dad18764c269a8a94301312b983','surveyor_guid_222','X-Ray Test Ref','X-RAY_TEST','NEW',NULL,1726588800,NULL,NULL,1726252071,'anonymous user',NULL),('d2c343f9cbd64a6181288cbcd5f57b2d','f3996dad18764c269a8a94301312b983','surveyor_guid_222','RO for demo','RELEASE_ORDER','MATCH',NULL,1726502400,1726271372,'system',1726252657,'anonymous user',NULL),('e6c4abde1cbd4219bc15e9a175e518ec','389b8f1138a14ce5b6550a3e7f79ae4a','surveyor_guid_222',NULL,'RELEASE_ORDER','NEW',NULL,1728835200,NULL,NULL,1728666054,'anonymous user',NULL),('f66cce8fb6294e37aef426c99379216c','fada38916c82458c96fd9ba238d5ce48','surveyor_guid_222','demo wrong date 18 sept','DYNE_PEN_TEST','NEW',NULL,1726588800,1726301197,'anonymous user',1726271299,'anonymous user',1726301197);
/*!40000 ALTER TABLE `booking` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-27 13:36:39
